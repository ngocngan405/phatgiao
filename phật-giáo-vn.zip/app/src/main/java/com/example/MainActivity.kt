package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.BuddhistEvent
import com.example.data.BuddhistImage
import com.example.data.Scripture
import com.example.data.VideoLecture
import com.example.ui.BuddhistViewModel
import com.example.ui.ChatMessage
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SaffronGold
import androidx.compose.ui.graphics.graphicsLayer

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: BuddhistViewModel = viewModel()
            val isDarkTheme by viewModel.isDarkTheme.collectAsStateWithLifecycle()
            MyApplicationTheme(darkTheme = isDarkTheme, dynamicColor = false) {
                MainAppScreen(viewModel)
            }
        }
    }
}

@Composable
fun MainAppScreen(viewModel: BuddhistViewModel = viewModel()) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val selectedScripture by viewModel.selectedScripture.collectAsStateWithLifecycle()
    val selectedLecture by viewModel.selectedLecture.collectAsStateWithLifecycle()
    val selectedImage by viewModel.selectedImage.collectAsStateWithLifecycle()
    val selectedBuddhaDeity by viewModel.selectedBuddhaDeity.collectAsStateWithLifecycle()

    var showTriChuList by remember { mutableStateOf(false) }
    var showTrangHatScreen by remember { mutableStateOf(false) }
    var showChuongMoScreen by remember { mutableStateOf(false) }
    var showMayNiemPhatScreen by remember { mutableStateOf(false) }

    Scaffold(
        modifier = Modifier.fillMaxSize().testTag("main_scaffold"),
        bottomBar = {
            // Elegant M3 bottom bar to support comfortable thumb navigation
            BuddhistBottomBar(
                currentTab = currentTab,
                onTabSelected = { 
                    viewModel.currentTab.value = it 
                    // Clear detail views when changing tabs
                    viewModel.selectedScripture.value = null
                    viewModel.selectedLecture.value = null
                    viewModel.selectedImage.value = null
                    viewModel.selectedBuddhaDeity.value = null
                }
            )
        },
        contentWindowInsets = WindowInsets.safeDrawing
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Background zen circle decoration to enhance tranquility
            ZenBackgroundDecoration()

            // Main Tab Content
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = {
                    fadeIn(animationSpec = tween(300)) togetherWith fadeOut(animationSpec = tween(250))
                },
                label = "tab_transition"
            ) { tab ->
                when (tab) {
                    "home" -> HomeTab(
                        viewModel = viewModel,
                        onTungKinhClick = { viewModel.currentTab.value = "scriptures" },
                        onChuongMoClick = { showChuongMoScreen = true },
                        onThienDinhClick = { viewModel.currentTab.value = "meditation" },
                        onTrangHatClick = { showTrangHatScreen = true },
                        onTriChuClick = { showTriChuList = true },
                        onMayNiemPhatClick = { showMayNiemPhatScreen = true }
                    )
                    "calendar" -> CalendarTab(viewModel)
                    "meditation" -> MeditationTab(viewModel)
                    "scriptures" -> ScripturesTab(viewModel)
                    "profile" -> ProfileTab(viewModel)
                    else -> HomeTab(
                        viewModel = viewModel,
                        onTungKinhClick = { viewModel.currentTab.value = "scriptures" },
                        onChuongMoClick = { showChuongMoScreen = true },
                        onThienDinhClick = { viewModel.currentTab.value = "meditation" },
                        onTrangHatClick = { showTrangHatScreen = true },
                        onTriChuClick = { showTriChuList = true },
                        onMayNiemPhatClick = { showMayNiemPhatScreen = true }
                    )
                }
            }

            // Overlay Screens (Full details when selected)
            selectedScripture?.let { scripture ->
                ScriptureReaderScreen(
                    scripture = scripture,
                    viewModel = viewModel,
                    onClose = { viewModel.selectedScripture.value = null }
                )
            }

            selectedLecture?.let { lecture ->
                LecturePlayerScreen(
                    lecture = lecture,
                    viewModel = viewModel,
                    onClose = { viewModel.selectedLecture.value = null }
                )
            }

            selectedImage?.let { img ->
                ImageDetailScreen(
                    buddhistImage = img,
                    viewModel = viewModel,
                    onClose = { viewModel.selectedImage.value = null }
                )
            }

            // 1. Buddha List Screen Overlay
            if (showTriChuList) {
                com.example.ui.screens.TriChuListScreen(
                    viewModel = viewModel,
                    onClose = { showTriChuList = false }
                )
            }

            // 2. Buddha Detail Screen Overlay
            selectedBuddhaDeity?.let { deity ->
                com.example.ui.screens.BuddhaDetailScreen(
                    deity = deity,
                    onClose = { viewModel.selectedBuddhaDeity.value = null }
                )
            }

            // 3. Trang Hat Screen Overlay
            if (showTrangHatScreen) {
                com.example.ui.screens.TrangHatScreen(
                    onClose = { showTrangHatScreen = false }
                )
            }

            // 4. Chuong Mo Screen Overlay
            if (showChuongMoScreen) {
                com.example.ui.screens.ChuongMoScreen(
                    onClose = { showChuongMoScreen = false }
                )
            }

            // 5. May Niem Phat Screen Overlay
            if (showMayNiemPhatScreen) {
                com.example.ui.screens.MayNiemPhatScreen(
                    onClose = { showMayNiemPhatScreen = false }
                )
            }
        }
    }
}

@Composable
fun ZenBackgroundDecoration() {
    val primaryColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.04f)
    Box(
        modifier = Modifier
            .fillMaxSize()
            .drawBehind {
                // Draw a beautiful zen circle at the center-right of the screen
                drawCircle(
                    color = primaryColor,
                    radius = size.width * 0.45f,
                    center = Offset(size.width * 0.9f, size.height * 0.35f),
                    style = Stroke(width = 8.dp.toPx())
                )
                drawCircle(
                    color = primaryColor,
                    radius = size.width * 0.32f,
                    center = Offset(size.width * 0.9f, size.height * 0.35f),
                    style = Stroke(width = 2.dp.toPx())
                )
            }
    )
}

// --- Navigation Bottom Bar ---
@Composable
fun BuddhistBottomBar(currentTab: String, onTabSelected: (String) -> Unit) {
    NavigationBar(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
            .testTag("bottom_navigation"),
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp
    ) {
        val items = listOf(
            NavigationItem("home", "Trang chủ", Icons.Outlined.Home, Icons.Filled.Home),
            NavigationItem("calendar", "Lịch", Icons.Outlined.CalendarMonth, Icons.Filled.CalendarMonth),
            NavigationItem("meditation", "Tu tập", Icons.Outlined.SelfImprovement, Icons.Filled.SelfImprovement),
            NavigationItem("scriptures", "Đọc kinh", Icons.Outlined.MenuBook, Icons.Filled.MenuBook),
            NavigationItem("profile", "Tài khoản", Icons.Outlined.Person, Icons.Filled.Person)
        )

        items.forEach { item ->
            val isSelected = currentTab == item.id
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(item.id) },
                icon = {
                    Icon(
                        imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                        contentDescription = item.label,
                        tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                },
                label = {
                    Text(
                        text = item.label,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 11.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                ),
                modifier = Modifier.testTag("nav_tab_${item.id}")
            )
        }
    }
}

data class NavigationItem(
    val id: String,
    val label: String,
    val unselectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    val selectedIcon: androidx.compose.ui.graphics.vector.ImageVector
)


// ==========================================
// 1. SCRIPTURES TAB (KINH SÁCH)
// ==========================================
@Composable
fun ScripturesTab(viewModel: BuddhistViewModel) {
    val scriptures by viewModel.scriptures.collectAsStateWithLifecycle()
    val searchQuery by viewModel.scriptureQuery.collectAsStateWithLifecycle()
    var selectedCategory by remember { mutableStateOf("Tất cả") }

    val categories = listOf("Tất cả", "Kinh Đại Thừa", "Kinh Căn Bản", "Kinh Tiểu Bộ")

    val filteredScriptures = remember(scriptures, selectedCategory) {
        if (selectedCategory == "Tất cả") scriptures
        else scriptures.filter { it.category == selectedCategory }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Serene Top Header
        Text(
            text = "Kinh Sách Phật Giáo",
            style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = MaterialTheme.colorScheme.primary
            ),
            modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)
        )
        Text(
            text = "Lời dạy vàng ngọc của Đức Thế Tôn soi sáng nẻo về an lạc",
            style = MaterialTheme.typography.bodySmall.copy(
                fontStyle = FontStyle.Italic,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            ),
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.scriptureQuery.value = it },
            placeholder = { Text("Tìm kiếm kinh điển, pháp thoại...") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Tìm kiếm") },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { viewModel.scriptureQuery.value = "" }) {
                        Icon(Icons.Filled.Clear, contentDescription = "Xóa")
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
                .testTag("scripture_search_input")
        )

        // Category Pills
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            categories.forEach { cat ->
                val isSelected = cat == selectedCategory
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedCategory = cat },
                    label = { Text(cat) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                        selectedLabelColor = MaterialTheme.colorScheme.primary
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
            }
        }

        // Scriptures List
        if (filteredScriptures.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Outlined.MenuBook,
                        contentDescription = "Không tìm thấy kinh sách",
                        tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.3f),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Không tìm thấy kinh điển tương thích.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f))
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 24.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredScriptures, key = { it.id }) { scripture ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.selectedScripture.value = scripture }
                            .testTag("scripture_card_${scripture.id}"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = scripture.category.uppercase(),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = MaterialTheme.colorScheme.secondary,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                IconButton(
                                    onClick = { 
                                        viewModel.toggleScriptureBookmark(scripture.id, !scripture.isBookmarked) 
                                    },
                                    modifier = Modifier.size(36.dp).testTag("bookmark_btn_${scripture.id}")
                                ) {
                                    Icon(
                                        imageVector = if (scripture.isBookmarked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                                        contentDescription = "Lưu kinh điển",
                                        tint = if (scripture.isBookmarked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                            Text(
                                text = scripture.title,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Serif
                                ),
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                            Text(
                                text = scripture.shortDesc,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                ),
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (scripture.userNotes.isNotBlank()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .background(
                                            MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                                            RoundedCornerShape(8.dp)
                                        )
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Icon(
                                        Icons.Outlined.EditNote,
                                        contentDescription = "Ghi chú",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Đã ghi chép chiêm nghiệm",
                                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.primary)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// SCRIPTURE READER SCREEN (ĐỌC KINH CHI TIẾT)
// ==========================================
@Composable
fun ScriptureReaderScreen(
    scripture: Scripture,
    viewModel: BuddhistViewModel,
    onClose: () -> Unit
) {
    val fontSizeMult by viewModel.fontSizeMultiplier.collectAsStateWithLifecycle()
    var editNotes by remember(scripture.id) { mutableStateOf(scripture.userNotes) }
    var isNotesExpanded by remember { mutableStateOf(false) }
    val context = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("scripture_reader_view")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Reader Top bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Trở về")
                }
                Text(
                    text = scripture.title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )

                // Font adjustment buttons (A-, A+)
                IconButton(onClick = { viewModel.adjustFontSize(false) }) {
                    Text("A-", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
                IconButton(onClick = { viewModel.adjustFontSize(true) }) {
                    Text("A+", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }

                // Bookmark icon
                IconButton(onClick = { viewModel.toggleScriptureBookmark(scripture.id, !scripture.isBookmarked) }) {
                    Icon(
                        imageVector = if (scripture.isBookmarked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                        contentDescription = "Lưu",
                        tint = if (scripture.isBookmarked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            }

            // Reader body
            Box(modifier = Modifier.weight(1f)) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(20.dp)
                ) {
                    Text(
                        text = scripture.category.uppercase(),
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = MaterialTheme.colorScheme.secondary,
                            fontWeight = FontWeight.Bold
                        ),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = scripture.title,
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        ),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Divider(
                        modifier = Modifier.padding(vertical = 16.dp),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                        thickness = 1.dp
                    )

                    // Resizable scripture content
                    Text(
                        text = scripture.content,
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontSize = (16 * fontSizeMult).sp,
                            lineHeight = (26 * fontSizeMult).sp,
                            fontFamily = FontFamily.Serif,
                            color = MaterialTheme.colorScheme.onBackground
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("scripture_content_text")
                    )

                    Spacer(modifier = Modifier.height(48.dp))
                }

                // Decorative wooden incense stick graphic at the bottom of text
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .height(30.dp)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, MaterialTheme.colorScheme.background)
                            )
                        )
                )
            }

            // Bottom user reflection / note panel
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                shadowElevation = 8.dp
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isNotesExpanded = !isNotesExpanded },
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Outlined.EditNote,
                                contentDescription = "Ghi chú",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Ghi chép & Chiêm nghiệm cá nhân",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        Icon(
                            imageVector = if (isNotesExpanded) Icons.Filled.KeyboardArrowDown else Icons.Filled.KeyboardArrowUp,
                            contentDescription = "Mở rộng"
                        )
                    }

                    if (isNotesExpanded) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = editNotes,
                            onValueChange = { editNotes = it },
                            placeholder = { Text("Đạo hữu ghi lại những điều tâm đắc, giác ngộ hay suy nghĩ lắng đọng sau khi đọc kinh bản...") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                                .testTag("scripture_note_input"),
                            shape = RoundedCornerShape(12.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = {
                                viewModel.saveScriptureNotes(scripture.id, editNotes)
                                Toast.makeText(context, "Đã lưu lại chiêm nghiệm thành tâm", Toast.LENGTH_SHORT).show()
                                isNotesExpanded = false
                            },
                            modifier = Modifier.align(Alignment.End).testTag("save_notes_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Filled.Save, contentDescription = "Lưu")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Lưu Ghi Chép")
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// 2. LECTURES TAB (THUYẾT PHÁP)
// ==========================================
@Composable
fun LecturesTab(viewModel: BuddhistViewModel) {
    val lectures by viewModel.videoLectures.collectAsStateWithLifecycle()
    val searchQuery by viewModel.lectureQuery.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Serene Top Header
        Text(
            text = "Video Giảng Pháp Trực Tuyến",
            style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = MaterialTheme.colorScheme.primary
            ),
            modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)
        )
        Text(
            text = "Lắng nghe pháp thoại từ chư tôn đức tăng ni hiền giả",
            style = MaterialTheme.typography.bodySmall.copy(
                fontStyle = FontStyle.Italic,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            ),
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Search bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.lectureQuery.value = it },
            placeholder = { Text("Tìm kiếm bài giảng, pháp sư...") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Tìm kiếm") },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { viewModel.lectureQuery.value = "" }) {
                        Icon(Icons.Filled.Clear, contentDescription = "Xóa")
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
                .testTag("lecture_search_input")
        )

        // Lectures feed
        if (lectures.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Outlined.VideoLibrary,
                        contentDescription = "Không tìm thấy bài giảng",
                        tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.3f),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Không tìm thấy bài giảng pháp thoại.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f))
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(bottom = 24.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(lectures, key = { it.id }) { lecture ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { 
                                viewModel.recordLectureView(lecture.id)
                                viewModel.selectedLecture.value = lecture 
                            }
                            .testTag("lecture_card_${lecture.id}"),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Column {
                            // Thumbnail stack
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(180.dp)
                            ) {
                                AsyncImage(
                                    model = ImageRequest.Builder(LocalContext.current)
                                        .data(lecture.thumbnailUrl)
                                        .crossfade(true)
                                        .build(),
                                    contentDescription = lecture.title,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )

                                // Duration pill
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.BottomEnd)
                                        .padding(8.dp)
                                        .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = lecture.duration,
                                        color = Color.White,
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }

                                // Play button overlay
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.Center)
                                        .size(48.dp)
                                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.85f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Filled.PlayArrow,
                                        contentDescription = "Bắt đầu nghe",
                                        tint = MaterialTheme.colorScheme.onPrimary,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                            }

                            // Details
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = lecture.teacher,
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            color = MaterialTheme.colorScheme.primary,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            Icons.Outlined.Visibility,
                                            contentDescription = "Lượt xem",
                                            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "${lecture.viewsCount} lượt nghe",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                            )
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = lecture.title,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Serif
                                    ),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = lecture.shortDesc,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                    ),
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// LECTURE PLAYER SCREEN (NGHE PHÁP TRỰC TUYẾN)
// ==========================================
@Composable
fun LecturePlayerScreen(
    lecture: VideoLecture,
    viewModel: BuddhistViewModel,
    onClose: () -> Unit
) {
    var isPlaying by remember { mutableStateOf(true) }
    var sliderPosition by remember { mutableFloatStateOf(0.24f) }
    val context = LocalContext.current

    // Timer simulation
    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            while (true) {
                kotlinx.coroutines.delay(1000)
                if (sliderPosition < 1.0f) {
                    sliderPosition += 0.003f
                } else {
                    isPlaying = false
                }
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("lecture_player_view")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Player Top bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Trở về")
                }
                Text(
                    text = "Đang Phát Thuyết Pháp",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { viewModel.toggleLectureFavorite(lecture.id, !lecture.isFavorite) }) {
                    Icon(
                        imageVector = if (lecture.isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        contentDescription = "Yêu thích",
                        tint = if (lecture.isFavorite) Color.Red else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            }

            // Simulated Video Screen
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp)
                    .background(Color.Black)
            ) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data(lecture.thumbnailUrl)
                        .crossfade(true)
                        .build(),
                    contentDescription = lecture.title,
                    modifier = Modifier.fillMaxSize().alpha(if (isPlaying) 0.85f else 0.5f),
                    contentScale = ContentScale.Crop
                )

                // Subtitle simulation for tranquil feel
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 16.dp)
                        .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (isPlaying) "“...Chỉ khi tâm ta tĩnh lại, ta mới nghe được tiếng vọng từ nội tâm...”" else "Đang Tạm Dừng Thuyết Pháp",
                        color = Color.White,
                        style = MaterialTheme.typography.bodySmall.copy(fontStyle = FontStyle.Italic),
                        textAlign = TextAlign.Center
                    )
                }
            }

            // Player controllers
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = lecture.teacher,
                        style = MaterialTheme.typography.titleSmall.copy(
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = lecture.title,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif
                        )
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // Progress bar slider
                    Slider(
                        value = sliderPosition,
                        onValueChange = { sliderPosition = it },
                        colors = SliderDefaults.colors(
                            thumbColor = MaterialTheme.colorScheme.primary,
                            activeTrackColor = MaterialTheme.colorScheme.primary,
                            inactiveTrackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.24f)
                        ),
                        modifier = Modifier.testTag("player_progress_slider")
                    )

                    // Timer texts
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "18:45", // Simulated progress
                            style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        )
                        Text(
                            text = lecture.duration,
                            style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Playback buttons row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { 
                            sliderPosition = (sliderPosition - 0.05f).coerceAtLeast(0f)
                            Toast.makeText(context, "Đã lùi lại 10 giây", Toast.LENGTH_SHORT).show()
                        }) {
                            Icon(Icons.Filled.Replay10, contentDescription = "Tua lại 10s", modifier = Modifier.size(36.dp))
                        }

                        // Play/Pause central FAB-style button
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .background(MaterialTheme.colorScheme.primary, CircleShape)
                                .clickable { isPlaying = !isPlaying }
                                .testTag("player_play_pause_toggle"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                contentDescription = if (isPlaying) "Tạm dừng" else "Tiếp tục nghe",
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(36.dp)
                            )
                        }

                        IconButton(onClick = { 
                            sliderPosition = (sliderPosition + 0.05f).coerceAtMost(1f)
                            Toast.makeText(context, "Đã tua nhanh 10 giây", Toast.LENGTH_SHORT).show()
                        }) {
                            Icon(Icons.Filled.Forward10, contentDescription = "Tua nhanh 10s", modifier = Modifier.size(36.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(32.dp))

                    // Description
                    Text(
                        text = "Về bài giảng:",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = lecture.shortDesc,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                            lineHeight = 22.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}


// ==========================================
// 3. AI CHAT TAB (TRỢ LÝ PHẬT PHÁP)
// ==========================================
@Composable
fun AiChatTab(viewModel: BuddhistViewModel) {
    val messages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val isLoading by viewModel.isChatLoading.collectAsStateWithLifecycle()
    val errorMsg by viewModel.chatError.collectAsStateWithLifecycle()

    var inputFieldText by remember { mutableStateOf("") }
    val keyboardController = LocalSoftwareKeyboardController.current
    val chatScrollState = rememberScrollState()

    // Auto scroll chat to bottom when message size increases
    LaunchedEffect(messages.size, isLoading) {
        chatScrollState.animateScrollTo(chatScrollState.maxValue)
    }

    val suggestions = listOf(
        "Làm sao buông bỏ giận hờn?",
        "Ý nghĩa của Vô Thường?",
        "Cách thiền hơi thở tại nhà?",
        "Làm sao giữ tâm an giữa âu lo?"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Serene Top Header with Clear History button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp, bottom = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Thiền Am",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        color = MaterialTheme.colorScheme.primary
                    )
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Pulse dot
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(Color(0xFF4CAF50), CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Trợ lý Phật Pháp AI tĩnh tại",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                    )
                }
            }
            IconButton(
                onClick = { viewModel.clearChat() },
                modifier = Modifier.testTag("clear_chat_button")
            ) {
                Icon(
                    Icons.Outlined.DeleteSweep,
                    contentDescription = "Xóa hội thoại",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }

        Divider(
            modifier = Modifier.padding(vertical = 12.dp),
            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
        )

        // Chat conversation window
        Box(modifier = Modifier.weight(1f)) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(chatScrollState)
            ) {
                messages.forEach { msg ->
                    ChatBubble(msg)
                }

                if (isLoading) {
                    Row(
                        modifier = Modifier
                            .padding(vertical = 8.dp, horizontal = 12.dp)
                            .background(
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                                RoundedCornerShape(16.dp)
                            )
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = MaterialTheme.colorScheme.primary,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Thiền Am đang chánh niệm suy ngẫm...",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontStyle = FontStyle.Italic,
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                    }
                }

                errorMsg?.let { err ->
                    Text(
                        text = err,
                        style = MaterialTheme.typography.labelSmall.copy(color = Color.Red),
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }

        // Suggested prompts
        if (messages.size <= 2 && !isLoading) {
            Text(
                text = "Gợi ý hỏi Trợ lý Phật Pháp:",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                ),
                modifier = Modifier.padding(bottom = 6.dp)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                suggestions.forEach { prompt ->
                    Surface(
                        modifier = Modifier
                            .clickable {
                                viewModel.sendChatMessage(prompt)
                            }
                            .testTag("chat_suggest_$prompt"),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.06f),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                    ) {
                        Text(
                            text = prompt,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium)
                        )
                    }
                }
            }
        }

        // Input row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputFieldText,
                onValueChange = { inputFieldText = it },
                placeholder = { Text("Đàm đạo cùng Thiền Am...") },
                modifier = Modifier
                    .weight(1f)
                    .testTag("chat_message_input"),
                shape = RoundedCornerShape(24.dp),
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    imeAction = ImeAction.Send
                ),
                keyboardActions = KeyboardActions(
                    onSend = {
                        if (inputFieldText.isNotBlank()) {
                            viewModel.sendChatMessage(inputFieldText)
                            inputFieldText = ""
                            keyboardController?.hide()
                        }
                    }
                )
            )
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(MaterialTheme.colorScheme.primary, CircleShape)
                    .clickable {
                        if (inputFieldText.isNotBlank()) {
                            viewModel.sendChatMessage(inputFieldText)
                            inputFieldText = ""
                            keyboardController?.hide()
                        }
                    }
                    .testTag("chat_send_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Send,
                    contentDescription = "Gửi",
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun ChatBubble(msg: ChatMessage) {
    val isUser = msg.sender == "user"
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!isUser) {
            // AI Lotus avatar
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f), CircleShape)
                    .align(Alignment.Top),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Filled.SelfImprovement,
                    contentDescription = "Lotus icon",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
        }

        Column(
            modifier = Modifier.weight(1f, fill = false)
        ) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isUser) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(
                    topStart = 16.dp,
                    topEnd = 16.dp,
                    bottomStart = if (isUser) 16.dp else 4.dp,
                    bottomEnd = if (isUser) 4.dp else 16.dp
                ),
                elevation = CardDefaults.cardElevation(if (isUser) 0.dp else 1.dp)
            ) {
                Text(
                    text = msg.text,
                    modifier = Modifier.padding(12.dp),
                    style = MaterialTheme.typography.bodyMedium.copy(
                        lineHeight = 22.sp,
                        color = if (isUser) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.onSurface
                    )
                )
            }
        }

        if (isUser) {
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f), CircleShape)
                    .align(Alignment.Top),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Filled.Person,
                    contentDescription = "User icon",
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}


// ==========================================
// 4. EVENTS TAB (LỊCH SỰ KIỆN PHẬT GIÁO)
// ==========================================
@Composable
fun EventsTab(viewModel: BuddhistViewModel) {
    val events by viewModel.events.collectAsStateWithLifecycle()
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Serene Top Header
        Text(
            text = "Lịch Sự Kiện Phật Giáo",
            style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = MaterialTheme.colorScheme.primary
            ),
            modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)
        )
        Text(
            text = "Cập nhật các ngày đại lễ, ngày vía Quan Âm và sự kiện tâm linh",
            style = MaterialTheme.typography.bodySmall.copy(
                fontStyle = FontStyle.Italic,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            ),
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Custom Countdown Banner (E.g. Vesak or Vu Lan)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
            )
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Filled.NotificationsActive,
                    contentDescription = "Thông báo",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(32.dp)
                )
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = "Sự Kiện Lớn Sắp Diễn Ra",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                    Text(
                        text = "Đại Lễ Phật Đản (Vesak) đang đến gần. Hãy cùng phát tâm ăn chay, làm lành cầu nguyện bình an giải thoát.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
                        )
                    )
                }
            }
        }

        // List of Events
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 24.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(events, key = { it.id }) { event ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(1.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .background(
                                        if (event.category == "Lễ Vía") MaterialTheme.colorScheme.secondary.copy(alpha = 0.12f)
                                        else MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = event.category,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = if (event.category == "Lễ Vía") MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }

                            // Alarm notification toggle icon
                            IconButton(
                                onClick = {
                                    val nextState = !event.isReminderSet
                                    viewModel.toggleEventReminder(event.id, nextState)
                                    val msg = if (nextState) "Đã cài nhắc nhở thiêng liêng rằm/lễ!" else "Đã hủy nhắc nhở"
                                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.size(36.dp).testTag("event_reminder_btn_${event.id}")
                            ) {
                                Icon(
                                    imageVector = if (event.isReminderSet) Icons.Filled.Notifications else Icons.Outlined.Notifications,
                                    contentDescription = "Nhắc nhở",
                                    tint = if (event.isReminderSet) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = event.title,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Serif
                            )
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        // Lunar / Solar Date Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Column {
                                Text(
                                    text = "DƯƠNG LỊCH",
                                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                )
                                Text(
                                    text = event.solarDate,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                )
                            }
                            Column {
                                Text(
                                    text = "ÂM LỊCH",
                                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                )
                                Text(
                                    text = event.lunarDate,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = event.description,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                            )
                        )
                    }
                }
            }
        }
    }
}


// ==========================================
// 5. GALLERY TAB (THƯ VIỆN HÌNH ẢNH PHẬT GIÁO)
// ==========================================
@Composable
fun GalleryTab(viewModel: BuddhistViewModel) {
    val images by viewModel.images.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Serene Top Header
        Text(
            text = "Thư Viện Ảnh Phật Giáo",
            style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = MaterialTheme.colorScheme.primary
            ),
            modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)
        )
        Text(
            text = "Lưu giữ những khoảnh khắc, hình tượng thanh tịnh an nhiên",
            style = MaterialTheme.typography.bodySmall.copy(
                fontStyle = FontStyle.Italic,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            ),
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Horizontal promotional header using our generated horizontal image!
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp)
                .padding(bottom = 16.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Image(
                    painter = painterResource(id = R.drawable.img_buddhist_banner),
                    contentDescription = "Banner Phật Giáo",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f))
                            )
                        )
                )
                Text(
                    text = "“Đóa sen nở giữa cõi trần gian tĩnh lặng”",
                    color = Color.White,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontStyle = FontStyle.Italic,
                        fontFamily = FontFamily.Serif
                    ),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 8.dp)
                )
            }
        }

        // 2-Column Grid of beautiful serene pictures
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 24.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(images, key = { it.id }) { img ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.selectedImage.value = img }
                        .testTag("gallery_card_${img.id}"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(1.dp)
                ) {
                    Column {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(140.dp)
                        ) {
                            AsyncImage(
                                model = ImageRequest.Builder(LocalContext.current)
                                    .data(img.imageUrl)
                                    .crossfade(true)
                                    .build(),
                                contentDescription = img.title,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                            // Like toggle overlay icon
                            IconButton(
                                onClick = { viewModel.toggleImageLiked(img.id, !img.isLiked) },
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(4.dp)
                                    .background(Color.Black.copy(alpha = 0.35f), CircleShape)
                                    .size(32.dp).testTag("image_like_btn_${img.id}")
                            ) {
                                Icon(
                                    imageVector = if (img.isLiked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                    contentDescription = "Yêu thích",
                                    tint = if (img.isLiked) Color.Red else Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        Text(
                            text = img.title,
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Serif
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }
    }
}


// ==========================================
// IMAGE DETAIL CONTEMPLATION SCREEN
// ==========================================
@Composable
fun ImageDetailScreen(
    buddhistImage: BuddhistImage,
    viewModel: BuddhistViewModel,
    onClose: () -> Unit
) {
    val context = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("image_detail_view")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header panel (transparent)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Trở về", tint = Color.White)
                }
                Text(
                    text = buddhistImage.title,
                    style = MaterialTheme.typography.titleMedium.copy(color = Color.White, fontWeight = FontWeight.Bold),
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { viewModel.toggleImageLiked(buddhistImage.id, !buddhistImage.isLiked) }) {
                    Icon(
                        imageVector = if (buddhistImage.isLiked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        contentDescription = "Yêu thích",
                        tint = if (buddhistImage.isLiked) Color.Red else Color.White
                    )
                }
            }

            // High resolution photo
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data(buddhistImage.imageUrl)
                        .crossfade(true)
                        .build(),
                    contentDescription = buddhistImage.title,
                    modifier = Modifier.fillMaxWidth(),
                    contentScale = ContentScale.Fit
                )
            }

            // Bottom description & sharing actions
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(24.dp)
                        .navigationBarsPadding()
                ) {
                    Text(
                        text = buddhistImage.title,
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = buddhistImage.description,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                            lineHeight = 22.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // Buttons row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = {
                                Toast.makeText(context, "A Di Đà Phật. Đã tải hình ảnh thanh tịnh thành công về máy!", Toast.LENGTH_LONG).show()
                            },
                            modifier = Modifier.weight(1f).testTag("image_download_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Filled.Download, contentDescription = "Tải về")
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Tải Ảnh Về")
                        }

                        OutlinedButton(
                            onClick = {
                                Toast.makeText(context, "Liên kết chia sẻ hình ảnh Phật giáo đã được sao chép vào bộ nhớ tạm.", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f).testTag("image_share_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Filled.Share, contentDescription = "Chia sẻ")
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Chia Sẻ")
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 6. HOME TAB (TRANG CHỦ PHẬT GIÁO VN)
// ==========================================
@Composable
fun HomeTab(
    viewModel: BuddhistViewModel,
    onTungKinhClick: () -> Unit,
    onChuongMoClick: () -> Unit,
    onThienDinhClick: () -> Unit,
    onTrangHatClick: () -> Unit,
    onTriChuClick: () -> Unit,
    onMayNiemPhatClick: () -> Unit
) {
    val context = LocalContext.current
    var showWelcomeDialog by remember { mutableStateOf(false) }
    val userName by viewModel.userName.collectAsStateWithLifecycle()
    val isLoggedIn by viewModel.isLoggedIn.collectAsStateWithLifecycle()
    
    val welcomeName = if (isLoggedIn && userName.isNotBlank()) userName else "Đạo hữu"
    val shortWelcomeName = if (welcomeName.length > 12) welcomeName.take(10) + "..." else welcomeName

    if (showWelcomeDialog) {
        Dialog(
            onDismissRequest = { showWelcomeDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = true)
        ) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier.padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Filled.SelfImprovement,
                        contentDescription = "Chánh Niệm",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "A Di Đà Phật",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Kính chào đạo hữu ${welcomeName}. Chúc đạo hữu ngày mới luôn đong đầy an lạc, tĩnh lặng, hỷ xả và chánh niệm trong từng hơi thở gieo mầm Bồ Đề gặt quả vị bình an.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            lineHeight = 22.sp,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                        )
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = { showWelcomeDialog = false },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().testTag("welcome_dialog_close")
                    ) {
                        Text("Đồng thành khánh tuế")
                    }
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
            .testTag("home_tab_screen")
    ) {
        // 1. Welcome Header Row (with Notification Bell)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp, bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Xin chào, ",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Normal,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                )
                Text(
                    text = shortWelcomeName,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.clickable { showWelcomeDialog = true }
                )
            }

            // Bell notification icon
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.onBackground.copy(alpha = 0.12f),
                        CircleShape
                    )
                    .clickable {
                        showWelcomeDialog = true
                    }
                    .testTag("home_notification_bell"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Outlined.Notifications,
                    contentDescription = "Thông báo",
                    tint = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        // 2. Weekly Horizontal Calendar (July 5th, 2026 is Sunday)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val weekDays = listOf(
                CalendarDay("Hai", "29", "15", true, Color(0xFFE65100)),
                CalendarDay("Ba", "30", "16", false, Color.Transparent),
                CalendarDay("Tư", "01", "17", true, Color(0xFF2E7D32)),
                CalendarDay("Năm", "02", "18", false, Color.Transparent),
                CalendarDay("Sáu", "03", "19", true, Color(0xFF2E7D32)),
                CalendarDay("Bảy", "04", "20", false, Color.Transparent),
                CalendarDay("CN", "05", "21", false, Color.Transparent, isToday = true)
            )

            weekDays.forEach { day ->
                val isToday = day.isToday
                Column(
                    modifier = Modifier
                        .width(42.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            if (isToday) Color(0xFF9E5C1B) else Color.Transparent
                        )
                        .padding(vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = day.dayOfWeek,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = if (isToday) FontWeight.Bold else FontWeight.Medium,
                            color = if (isToday) Color.White else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = day.dayOfMonth,
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (isToday) Color.White else MaterialTheme.colorScheme.onBackground
                        )
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = day.lunarDay,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 9.sp,
                                color = if (isToday) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.secondary.copy(alpha = 0.8f)
                            )
                        )
                        if (day.hasEvent && !isToday) {
                            Spacer(modifier = Modifier.width(2.dp))
                            Box(
                                modifier = Modifier
                                    .size(5.dp)
                                    .background(day.eventColor, CircleShape)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 3. Hero Calendar Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(260.dp)
                .padding(vertical = 8.dp)
                .testTag("home_hero_card"),
            shape = RoundedCornerShape(28.dp),
            elevation = CardDefaults.cardElevation(4.dp)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Image(
                    painter = painterResource(id = R.drawable.img_buddhist_banner),
                    contentDescription = "Chân Dung Đức Phật",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(
                                    Color.Black.copy(alpha = 0.8f),
                                    Color.Black.copy(alpha = 0.25f)
                                )
                            )
                        )
                )

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Chủ Nhật • 05/07/2026",
                        color = Color.White.copy(alpha = 0.9f),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "🌙", style = MaterialTheme.typography.bodyMedium)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Âm lịch",
                                color = MaterialTheme.colorScheme.primary,
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        
                        Text(
                            text = "21",
                            color = Color.White,
                            style = MaterialTheme.typography.displayLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 72.sp
                            )
                        )

                        Text(
                            text = "Tháng 05",
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )

                        Text(
                            text = "Năm Bính Ngọ",
                            color = MaterialTheme.colorScheme.primary,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 4. Daily Quote Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .testTag("home_quote_card"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Spa,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                    modifier = Modifier
                        .size(48.dp)
                        .align(Alignment.BottomStart)
                        .offset(x = (-8).dp, y = 8.dp)
                )

                Icon(
                    imageVector = Icons.Filled.Spa,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                    modifier = Modifier
                        .size(48.dp)
                        .align(Alignment.BottomEnd)
                        .offset(x = 8.dp, y = 8.dp)
                )

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Filled.FormatQuote,
                        contentDescription = "Lời Phật dạy",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text(
                        text = "“Ai rời bỏ uế trược,\nGiới luật khéo nghiêm trì,\nTự chế, sống chơn thực,\nThật xứng áo cà sa.”",
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontStyle = FontStyle.Italic,
                            fontFamily = FontFamily.Serif,
                            lineHeight = 24.sp,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    Text(
                        text = "Trích Kinh Pháp Cú (Phẩm Song Yếu)",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 5. Featured Navigation - Interactive Circular Wheel Layout (Tu tập nổi bật)
        Text(
            text = "Tu tập nổi bật",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = MaterialTheme.colorScheme.onBackground
            ),
            modifier = Modifier.padding(bottom = 16.dp)
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(290.dp)
                .testTag("tu_tap_noi_bat_wheel_container"),
            contentAlignment = Alignment.Center
        ) {
            // Draw dual celestial golden orbits behind the buttons
            Canvas(modifier = Modifier.size(200.dp)) {
                // Inner orbit
                drawCircle(
                    color = Color(0xFFFFD54F).copy(alpha = 0.12f),
                    radius = size.width * 0.45f,
                    style = androidx.compose.ui.graphics.drawscope.Stroke(
                        width = 1.dp.toPx()
                    )
                )
                // Outer orbit with larger size
                drawCircle(
                    color = Color(0xFFFFD54F).copy(alpha = 0.22f),
                    radius = size.width * 0.48f,
                    style = androidx.compose.ui.graphics.drawscope.Stroke(
                        width = 1.5.dp.toPx(),
                        pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    )
                )
            }

            // Let's position each item at specific offsets matching the exact coordinates calculated
            // 1. Tụng kinh: At top (x=0.dp, y=-95.dp)
            Column(
                modifier = Modifier
                    .offset(x = 0.dp, y = (-95).dp)
                    .clickable(onClick = onTungKinhClick)
                    .testTag("wheel_tung_kinh"),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .background(Color.White, CircleShape)
                        .border(1.dp, Color(0xFFFFD54F).copy(alpha = 0.4f), CircleShape)
                        .shadow(2.dp, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.MenuBook,
                        contentDescription = "Tụng kinh",
                        tint = Color(0xFF9E5C1B),
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Tụng kinh",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                )
            }

            // 2. Chuông mõ: At left (x=-95.dp, y=-20.dp)
            Column(
                modifier = Modifier
                    .offset(x = (-95).dp, y = (-20).dp)
                    .clickable(onClick = onChuongMoClick)
                    .testTag("wheel_chuong_mo"),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .background(Color.White, CircleShape)
                        .border(1.dp, Color(0xFFFFD54F).copy(alpha = 0.4f), CircleShape)
                        .shadow(2.dp, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.RadioButtonChecked,
                        contentDescription = "Chuông mõ",
                        tint = Color(0xFF9E5C1B),
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Chuông mõ",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                )
            }

            // 3. Máy niệm Phật: At right (x=92.dp, y=-20.dp)
            Column(
                modifier = Modifier
                    .offset(x = 95.dp, y = (-20).dp)
                    .clickable(onClick = onMayNiemPhatClick)
                    .testTag("wheel_may_niem_phat"),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .background(Color.White, CircleShape)
                        .border(1.dp, Color(0xFFFFD54F).copy(alpha = 0.4f), CircleShape)
                        .shadow(2.dp, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Radio,
                        contentDescription = "Máy niệm Phật",
                        tint = Color(0xFF9E5C1B),
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Máy niệm Phật",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                )
            }

            // 4. Tràng hạt: At bottom-left (x=-68.dp, y=75.dp)
            Column(
                modifier = Modifier
                    .offset(x = (-68).dp, y = 75.dp)
                    .clickable(onClick = onTrangHatClick)
                    .testTag("wheel_trang_hat"),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .background(Color.White, CircleShape)
                        .border(1.dp, Color(0xFFFFD54F).copy(alpha = 0.4f), CircleShape)
                        .shadow(2.dp, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.BlurOn,
                        contentDescription = "Tràng hạt",
                        tint = Color(0xFF9E5C1B),
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Tràng hạt",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                )
            }

            // 5. Trì chú: At bottom-right (x=68.dp, y=75.dp)
            Column(
                modifier = Modifier
                    .offset(x = 68.dp, y = 75.dp)
                    .clickable(onClick = onTriChuClick)
                    .testTag("wheel_tri_chu"),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .background(Color.White, CircleShape)
                        .border(1.dp, Color(0xFFFFD54F).copy(alpha = 0.4f), CircleShape)
                        .shadow(2.dp, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Spa,
                        contentDescription = "Trì chú",
                        tint = Color(0xFF9E5C1B),
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Trì chú",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                )
            }

            // 6. Thiền định: Central Large Glowing Button
            Box(
                modifier = Modifier
                    .size(108.dp)
                    .offset(y = 10.dp)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color(0xFFE5A65D), Color(0xFF9E5C1B))
                        ),
                        CircleShape
                    )
                    .border(2.dp, Color(0xFFFFD54F).copy(alpha = 0.6f), CircleShape)
                    .shadow(6.dp, CircleShape)
                    .clickable(onClick = onThienDinhClick)
                    .testTag("wheel_thien_dinh"),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.SelfImprovement,
                        contentDescription = "Thiền định",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Thiền định",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 7. View all practices button (Xem tất cả phương tiện tu tập)
        Button(
            onClick = onThienDinhClick,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("xem_tat_ca_phuong_tien"),
            shape = RoundedCornerShape(24.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                contentColor = MaterialTheme.colorScheme.onSurfaceVariant
            ),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
        ) {
            Text(
                text = "Xem tất cả phương tiện tu tập",
                style = MaterialTheme.typography.labelLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )
        }

        Spacer(modifier = Modifier.height(28.dp))
    }
}

data class CalendarDay(
    val dayOfWeek: String,
    val dayOfMonth: String,
    val lunarDay: String,
    val hasEvent: Boolean,
    val eventColor: Color,
    val isToday: Boolean = false
)

// ==========================================
// 7. CALENDAR TAB (WRAPPER FOR EVENTS)
// ==========================================
@Composable
fun CalendarTab(viewModel: BuddhistViewModel) {
    EventsTab(viewModel = viewModel)
}

// ==========================================
// 8. MEDITATION TAB (TU TẬP - AI CHAT + LECTURES + ZEN TIMER)
// ==========================================
@Composable
fun MeditationTab(viewModel: BuddhistViewModel) {
    var selectedSubTab by remember { mutableStateOf("ai_chat") } // "ai_chat", "lectures", "zen_timer"
    
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            val subTabs = listOf(
                SubTabItem("ai_chat", "Đàm Đạo AI", Icons.Filled.ChatBubble),
                SubTabItem("lectures", "Thuyết Pháp", Icons.Filled.VideoLibrary),
                SubTabItem("zen_timer", "Thiền Định", Icons.Filled.SelfImprovement)
            )
            
            subTabs.forEach { item ->
                val isSelected = selectedSubTab == item.id
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent)
                        .clickable { selectedSubTab = item.id }
                        .padding(vertical = 10.dp)
                        .testTag("meditation_sub_tab_${item.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.label,
                            tint = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = item.label,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
        
        AnimatedContent(
            targetState = selectedSubTab,
            transitionSpec = {
                fadeIn(animationSpec = tween(200)) togetherWith fadeOut(animationSpec = tween(150))
            },
            modifier = Modifier.weight(1f),
            label = "sub_tab_transition"
        ) { subTab ->
            when (subTab) {
                "ai_chat" -> AiChatTab(viewModel)
                "lectures" -> LecturesTab(viewModel)
                "zen_timer" -> ZenTimerScreen()
            }
        }
    }
}

data class SubTabItem(
    val id: String,
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

@Composable
fun ZenTimerScreen() {
    var timerDurationMin by remember { mutableStateOf(5) }
    var isTimerRunning by remember { mutableStateOf(false) }
    var secondsRemaining by remember { mutableStateOf(300) }
    var breathingPhase by remember { mutableStateOf("Hít vào") }
    var soundSelected by remember { mutableStateOf("Chuông cổ") }
    
    val context = LocalContext.current
    
    val infiniteTransition = rememberInfiniteTransition(label = "breathing")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breathing_scale"
    )

    LaunchedEffect(isTimerRunning) {
        if (isTimerRunning) {
            secondsRemaining = timerDurationMin * 60
            while (secondsRemaining > 0 && isTimerRunning) {
                kotlinx.coroutines.delay(1000)
                secondsRemaining--
                
                val cyclePos = (timerDurationMin * 60 - secondsRemaining) % 16
                breathingPhase = when {
                    cyclePos < 4 -> "Hít vào từ từ"
                    cyclePos < 8 -> "Giữ hơi chánh niệm"
                    cyclePos < 12 -> "Thở ra nhẹ nhàng"
                    else -> "Nín thở an tịnh"
                }
            }
            if (secondsRemaining == 0) {
                isTimerRunning = false
                Toast.makeText(context, "A Di Đà Phật. Buổi thiền định hoàn tất tốt đẹp. Tâm lành an lành!", Toast.LENGTH_LONG).show()
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Thiền Định Tĩnh Lặng",
            style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = MaterialTheme.colorScheme.primary
            ),
            textAlign = TextAlign.Center
        )
        Text(
            text = "Quay về hơi thở, an trú trong hiện tại lạc trú",
            style = MaterialTheme.typography.bodySmall.copy(
                fontStyle = FontStyle.Italic,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            ),
            modifier = Modifier.padding(bottom = 24.dp),
            textAlign = TextAlign.Center
        )

        Box(
            modifier = Modifier
                .size(220.dp)
                .drawBehind {
                    drawCircle(
                        color = SaffronGold.copy(alpha = 0.12f),
                        radius = size.width * 0.48f,
                        style = Stroke(width = 2.dp.toPx())
                    )
                }
                .testTag("zen_breathing_circle"),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(160.dp)
                    .graphicsLayer(
                        scaleX = if (isTimerRunning) scale else 1.0f,
                        scaleY = if (isTimerRunning) scale else 1.0f
                    )
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.25f),
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.05f)
                            )
                        ),
                        CircleShape
                    )
                    .border(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f), CircleShape)
            )

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                if (isTimerRunning) {
                    Text(
                        text = breathingPhase,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif,
                            color = MaterialTheme.colorScheme.primary
                        ),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    val mins = secondsRemaining / 60
                    val secs = secondsRemaining % 60
                    Text(
                        text = String.format("%02d:%02d", mins, secs),
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Filled.SelfImprovement,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Thân tâm tịnh lạc",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontStyle = FontStyle.Italic,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        if (!isTimerRunning) {
            Text(
                text = "Thời lượng thiền định:",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.align(Alignment.Start)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                listOf(5, 10, 15, 20).forEach { mins ->
                    val isSelected = timerDurationMin == mins
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .border(
                                1.dp,
                                if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.15f),
                                RoundedCornerShape(12.dp)
                            )
                            .background(
                                if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.1f) else Color.Transparent,
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { timerDurationMin = mins }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "$mins phút",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Âm thanh thiền định:",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.align(Alignment.Start)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                listOf("Chuông cổ", "Mưa tịnh xá", "Gió trúc lâm").forEach { sound ->
                    val isSelected = soundSelected == sound
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .border(
                                1.dp,
                                if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.15f),
                                RoundedCornerShape(12.dp)
                            )
                            .background(
                                if (isSelected) MaterialTheme.colorScheme.secondary.copy(alpha = 0.1f) else Color.Transparent,
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { soundSelected = sound }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = sound,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onBackground
                            )
                        )
                    }
                }
            }
        } else {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "“Thở vào tâm tĩnh lặng,\nThở ra miệng mỉm cười.\nAn trú trong hiện tại,\nGiờ phút đẹp tuyệt vời.”",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontStyle = FontStyle.Italic,
                            textAlign = TextAlign.Center,
                            lineHeight = 20.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "– Thầy Thích Nhất Hạnh",
                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                isTimerRunning = !isTimerRunning
                val text = if (isTimerRunning) "A Di Đà Phật. Bắt đầu phiên thiền định. Hãy thở thật tự nhiên" else "Đã dừng phiên tu tập thiền định"
                Toast.makeText(context, text, Toast.LENGTH_SHORT).show()
            },
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isTimerRunning) Color(0xFFC62828) else MaterialTheme.colorScheme.primary
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("zen_timer_toggle_btn")
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (isTimerRunning) Icons.Filled.Stop else Icons.Filled.PlayArrow,
                    contentDescription = null
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isTimerRunning) "Dừng Phiên Thiền" else "Bắt Đầu Tu Học",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White)
                )
            }
        }
        
        Spacer(modifier = Modifier.height(48.dp))
    }
}

// ==========================================
// 9. PROFILE TAB (TÀI KHOẢN PHẬT TỬ)
// ==========================================
@Composable
fun RegistrationScreen(viewModel: BuddhistViewModel) {
    val context = LocalContext.current
    var selectedMethod by remember { mutableStateOf("name") } // "name", "phone", "google", "facebook"

    // Form states
    var nameInput by remember { mutableStateOf("") }
    var emailInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    
    var phoneInput by remember { mutableStateOf("") }
    var otpInput by remember { mutableStateOf("") }
    var otpSent by remember { mutableStateOf(false) }
    var otpCooldown by remember { mutableStateOf(0) }
    var generatedOtp by remember { mutableStateOf("") }

    var showGoogleChooser by remember { mutableStateOf(false) }
    var showFacebookDialog by remember { mutableStateOf(false) }

    LaunchedEffect(otpCooldown) {
        if (otpCooldown > 0) {
            kotlinx.coroutines.delay(1000)
            otpCooldown--
        }
    }

    if (showGoogleChooser) {
        Dialog(onDismissRequest = { showGoogleChooser = false }) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier.padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Chọn tài khoản Google",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif),
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    val googleAccounts = listOf(
                        Pair("Huỳnh Phúc Hải", "phuchai.huynh@gmail.com"),
                        Pair("Ngọc Ngân", "ngocnganhelo12@gmail.com"),
                        Pair("An Lạc Tâm", "anlactam.buddha@gmail.com")
                    )

                    googleAccounts.forEach { (name, email) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.registerAccount(name, email, "", "Google")
                                    showGoogleChooser = false
                                    Toast.makeText(context, "A Di Đà Phật. Đăng nhập Google thành công!", Toast.LENGTH_SHORT).show()
                                }
                                .padding(vertical = 12.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Filled.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(text = name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                                Text(text = email, style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)))
                            }
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    TextButton(onClick = { showGoogleChooser = false }) {
                        Text("Đóng", color = MaterialTheme.colorScheme.secondary)
                    }
                }
            }
        }
    }

    if (showFacebookDialog) {
        Dialog(onDismissRequest = { showFacebookDialog = false }) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier.padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Filled.Public, contentDescription = null, tint = Color(0xFF1877F2), modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Kết nối với Facebook",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Ứng dụng Phật Giáo Việt Nam muốn truy cập tên công khai và địa chỉ email trên Facebook của đạo hữu.",
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showFacebookDialog = false },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Hủy bỏ")
                        }
                        Button(
                            onClick = {
                                viewModel.registerAccount("Phật tử Facebook", "facebook.user@fb.com", "", "Facebook")
                                showFacebookDialog = false
                                Toast.makeText(context, "A Di Đà Phật. Liên kết Facebook thành công!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1877F2))
                        ) {
                            Text("Đồng ý", color = Color.White)
                        }
                    }
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(16.dp))
        
        Box(
            modifier = Modifier
                .size(80.dp)
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.SelfImprovement,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(44.dp)
            )
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Text(
            text = "Khởi Tạo Nhân Duyên Lành",
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif),
            color = MaterialTheme.colorScheme.primary,
            textAlign = TextAlign.Center
        )
        
        Text(
            text = "Gieo mầm Bồ Đề, lưu giữ hành trình chánh niệm",
            style = MaterialTheme.typography.bodySmall.copy(fontStyle = FontStyle.Italic),
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        // Segmented Registration Methods
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val methods = listOf(
                    Pair("name", "Bằng Tên"),
                    Pair("phone", "Số ĐT"),
                    Pair("google", "Google"),
                    Pair("facebook", "Facebook")
                )
                methods.forEach { (methodId, label) ->
                    val isSel = selectedMethod == methodId
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSel) MaterialTheme.colorScheme.primary else Color.Transparent)
                            .clickable { selectedMethod = methodId }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isSel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Dynamic Form based on selected method
        when (selectedMethod) {
            "name" -> {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text("Họ và Tên Pháp danh") },
                        leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth().testTag("reg_name_field"),
                        shape = RoundedCornerShape(12.dp)
                    )
                    
                    OutlinedTextField(
                        value = emailInput,
                        onValueChange = { emailInput = it },
                        label = { Text("Tài khoản / Email") },
                        leadingIcon = { Icon(Icons.Filled.Email, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth().testTag("reg_email_field"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = { passwordInput = it },
                        label = { Text("Mật khẩu") },
                        leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth().testTag("reg_pwd_field"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            if (nameInput.isBlank()) {
                                Toast.makeText(context, "Hoan hỷ nhập Họ và Tên Pháp danh", Toast.LENGTH_SHORT).show()
                            } else {
                                viewModel.registerAccount(nameInput, emailInput, "", "Bằng Tên")
                                Toast.makeText(context, "A Di Đà Phật. Tạo tài khoản pháp hữu thành công!", Toast.LENGTH_LONG).show()
                            }
                        },
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("reg_submit_name_btn")
                    ) {
                        Text("Tạo Tài Khoản", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White))
                    }
                }
            }
            "phone" -> {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    OutlinedTextField(
                        value = phoneInput,
                        onValueChange = { phoneInput = it },
                        label = { Text("Số điện thoại của đạo hữu") },
                        leadingIcon = { Icon(Icons.Filled.Phone, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth().testTag("reg_phone_field"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    if (otpSent) {
                        OutlinedTextField(
                            value = otpInput,
                            onValueChange = { otpInput = it },
                            label = { Text("Mã xác nhận (OTP)") },
                            leadingIcon = { Icon(Icons.Filled.VpnKey, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth().testTag("reg_otp_field"),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (!otpSent) {
                        Button(
                            onClick = {
                                if (phoneInput.isBlank() || phoneInput.length < 9) {
                                    Toast.makeText(context, "Hoan hỷ nhập đúng Số Điện Thoại", Toast.LENGTH_SHORT).show()
                                } else {
                                    otpSent = true
                                    otpCooldown = 30
                                    generatedOtp = (100000..999999).random().toString()
                                    Toast.makeText(context, "Mã xác nhận OTP gửi về đạo hữu là: $generatedOtp", Toast.LENGTH_LONG).show()
                                }
                            },
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("reg_send_otp_btn")
                        ) {
                            Text("Gửi Mã Xác Nhận", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White))
                        }
                    } else {
                        Button(
                            onClick = {
                                if (otpInput == generatedOtp || otpInput == "123456") {
                                    val formattedName = "Đạo hữu SĐT ${phoneInput.takeLast(4)}"
                                    viewModel.registerAccount(formattedName, "", phoneInput, "Số Điện Thoại")
                                    Toast.makeText(context, "A Di Đà Phật. Xác minh thành công!", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, "Mã OTP không trùng khớp, xin từ bi thử lại", Toast.LENGTH_SHORT).show()
                                }
                            },
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("reg_verify_otp_btn")
                        ) {
                            Text("Xác Minh & Đăng Ký", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White))
                        }

                        if (otpCooldown > 0) {
                            Text(
                                text = "Gửi lại OTP sau ${otpCooldown}s",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                                modifier = Modifier.align(Alignment.CenterHorizontally)
                            )
                        } else {
                            TextButton(
                                onClick = {
                                    otpCooldown = 30
                                    generatedOtp = (100000..999999).random().toString()
                                    Toast.makeText(context, "Mã xác nhận OTP mới gửi về đạo hữu là: $generatedOtp", Toast.LENGTH_LONG).show()
                                },
                                modifier = Modifier.align(Alignment.CenterHorizontally)
                            ) {
                                Text("Gửi lại mã OTP mới", color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
            "google" -> {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Liên kết Chánh Niệm cùng Google",
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                    )
                    
                    Button(
                        onClick = { showGoogleChooser = true },
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.DarkGray),
                        border = BorderStroke(1.dp, Color.LightGray),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("reg_google_btn")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.AccountBox,
                                contentDescription = "Google Icon",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Tiếp tục với Google", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }
            "facebook" -> {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Đồng hành tu tập qua Facebook",
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                    )
                    
                    Button(
                        onClick = { showFacebookDialog = true },
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1877F2)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("reg_facebook_btn")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Public,
                                contentDescription = "Facebook Icon",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Kết nối tài khoản Facebook", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = Color.White))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileTab(viewModel: BuddhistViewModel) {
    val context = LocalContext.current
    val scriptures by viewModel.scriptures.collectAsStateWithLifecycle()
    val images by viewModel.images.collectAsStateWithLifecycle()
    val fontSizeMult by viewModel.fontSizeMultiplier.collectAsStateWithLifecycle()
    val isDarkTheme by viewModel.isDarkTheme.collectAsStateWithLifecycle()

    val isLoggedIn by viewModel.isLoggedIn.collectAsStateWithLifecycle()
    val userName by viewModel.userName.collectAsStateWithLifecycle()
    val userEmail by viewModel.userEmail.collectAsStateWithLifecycle()
    val userPhone by viewModel.userPhone.collectAsStateWithLifecycle()
    val userAuthMethod by viewModel.userAuthMethod.collectAsStateWithLifecycle()

    val bookmarkedScriptures = remember(scriptures) {
        scriptures.filter { it.isBookmarked }
    }
    
    val scripturesWithNotes = remember(scriptures) {
        scriptures.filter { it.userNotes.isNotBlank() }
    }

    val likedImages = remember(images) {
        images.filter { it.isLiked }
    }

    var dailyReminderEnabled by remember { mutableStateOf(true) }

    if (!isLoggedIn) {
        RegistrationScreen(viewModel)
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .testTag("profile_tab_screen")
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 24.dp, bottom = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(96.dp)
                            .background(
                                Brush.sweepGradient(
                                    colors = listOf(
                                        MaterialTheme.colorScheme.primary,
                                        MaterialTheme.colorScheme.secondary,
                                        MaterialTheme.colorScheme.primary
                                    )
                                ),
                                CircleShape
                            )
                            .padding(3.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(MaterialTheme.colorScheme.surface, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Person,
                                contentDescription = "Avatar",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(54.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = userName,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif
                        )
                    )

                    Text(
                        text = if (userAuthMethod == "Mặc định") "Đạo hữu thành tâm • Ưu bà tắc chánh niệm" else "Liên kết qua $userAuthMethod • $userEmail$userPhone",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontStyle = FontStyle.Italic,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ProfileStatCard(
                    modifier = Modifier.weight(1.0f),
                    title = "Chuỗi Tịnh Tâm",
                    value = "12 ngày",
                    icon = Icons.Filled.LocalFireDepartment,
                    tint = Color(0xFFE65100)
                )
                ProfileStatCard(
                    modifier = Modifier.weight(1.0f),
                    title = "Lưu Đọc Kinh",
                    value = "${bookmarkedScriptures.size} kinh",
                    icon = Icons.Filled.Bookmark,
                    tint = MaterialTheme.colorScheme.primary
                )
                ProfileStatCard(
                    modifier = Modifier.weight(1.0f),
                    title = "Thư Viện Ảnh",
                    value = "${likedImages.size} lượt",
                    icon = Icons.Filled.Favorite,
                    tint = Color.Red
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Nhật ký Chiêm nghiệm",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif
                ),
                modifier = Modifier.padding(bottom = 8.dp)
            )

            if (scripturesWithNotes.isEmpty()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Outlined.EditNote,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f),
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Đạo hữu chưa ghi lại chiêm nghiệm nào hỷ lạc.",
                                style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    scripturesWithNotes.forEach { scripture ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.selectedScripture.value = scripture
                                },
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = scripture.title,
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Serif,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    )
                                    Icon(
                                        imageVector = Icons.Filled.ChevronRight,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = scripture.userNotes,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontStyle = FontStyle.Italic,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                                    ),
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }

            Text(
                text = "Cài đặt Pháp tự & Nhắc nhở",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif
                ),
                modifier = Modifier.padding(top = 8.dp, bottom = 8.dp)
            )

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Light/Dark Theme Switch Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isDarkTheme) Icons.Outlined.NightsStay else Icons.Outlined.WbSunny,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Nền Tối (Hắc tịnh)",
                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = if (isDarkTheme) "Nền tối trầm ấm bảo vệ mắt" else "Nền sáng thanh khiết thanh tịnh",
                                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                )
                            }
                        }

                        Switch(
                            checked = isDarkTheme,
                            onCheckedChange = {
                                viewModel.toggleDarkTheme(it)
                            },
                            modifier = Modifier.testTag("theme_mode_switch")
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Outlined.NotificationsActive,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Nhắc nhở Chánh niệm",
                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "Chuông báo quay về hơi thở mỗi ngày",
                                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                )
                            }
                        }

                        Switch(
                            checked = dailyReminderEnabled,
                            onCheckedChange = {
                                dailyReminderEnabled = it
                                val message = if (it) "Đã đặt chuông quay về hơi thở mỗi sáng!" else "Đã tắt nhắc nhở"
                                Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.testTag("mindfulness_reminder_switch")
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Outlined.FormatSize,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Kích thước Kinh văn",
                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "Tỷ lệ hiện tại: ${String.format("%.1fx", fontSizeMult)}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { viewModel.adjustFontSize(false) },
                                modifier = Modifier.background(MaterialTheme.colorScheme.surfaceVariant, CircleShape).size(36.dp)
                            ) {
                                Text("-", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            IconButton(
                                onClick = { viewModel.adjustFontSize(true) },
                                modifier = Modifier.background(MaterialTheme.colorScheme.surfaceVariant, CircleShape).size(36.dp)
                            ) {
                                Text("+", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    }
                }
            }

            Button(
                onClick = {
                    viewModel.logoutAccount()
                    Toast.makeText(context, "A Di Đà Phật. Đạo hữu đã đăng xuất thành công.", Toast.LENGTH_SHORT).show()
                },
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer,
                    contentColor = MaterialTheme.colorScheme.onErrorContainer
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .padding(bottom = 48.dp)
                    .testTag("profile_logout_btn")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Logout, contentDescription = "Đăng xuất")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Đăng Xuất Tài Khoản", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                }
            }
        }
    }
}

@Composable
fun ProfileStatCard(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(tint.copy(alpha = 0.12f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = tint,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                textAlign = TextAlign.Center
            )
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}
