package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Vietnamese Buddhist Color Palette
val SaffronGold = Color(0xFFD29022)       // Ancient temple gold & monk robe color
val SaffronLight = Color(0xFFF0AF4C)      // Soft gold glow
val LotusPink = Color(0xFFD35574)         // Pure pink lotus
val LotusSoft = Color(0xFFE28CA0)         // Pale lotus petals
val AncientWood = Color(0xFF1D1410)       // Deep brown sandalwood, temple columns
val WoodMedium = Color(0xFF33221A)        // Medium wood paneling
val IncenseBeige = Color(0xFFF9F4EC)      // Warm light cream, incense ash hue
val PureBeige = Color(0xFFFFFDF9)         // Pure bright temple flag white/beige
val DarkText = Color(0xFF2E241F)          // Highly readable charcoal-brown text
val LightText = Color(0xFFEFE8E1)         // Light cream text for dark backgrounds
val ForestGreen = Color(0xFF385E38)       // Banyan tree leaves, tranquil garden
val SageGreen = Color(0xFF708F70)         // Soft zen green
val ShadowGold = Color(0xFF261D16)        // Rich background shadow with a hint of gold

