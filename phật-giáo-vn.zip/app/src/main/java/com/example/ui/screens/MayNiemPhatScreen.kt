package com.example.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class ChantStream(
    val id: Int,
    val title: String,
    val source: String,
    val durationText: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MayNiemPhatScreen(
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val sharedPrefs = context.getSharedPreferences("may_niem_phat_prefs", Context.MODE_PRIVATE)
    
    val streams = listOf(
        ChantStream(1, "Nam Mô A Di Đà Phật", "Đại đức Thích Trí Thoát trì tụng", "Vòng lặp vô tận"),
        ChantStream(2, "Thần Chú Đại Bi", "Mật tông trì tụng oai linh", "Vòng lặp vô tận"),
        ChantStream(3, "Nam Mô Quán Thế Âm Bồ Tát", "Bình an cát tường trì niệm", "Vòng lặp vô tận"),
        ChantStream(4, "Thần Chú Dược Sư", "Tiêu trừ ách bệnh ách tai", "Vòng lặp vô tận")
    )
    
    var selectedStreamId by remember { mutableStateOf(streams[0].id) }
    var isPlaying by remember { mutableStateOf(false) }
    var volume by remember { mutableStateOf(0.7f) }
    var countPlayed by remember { mutableStateOf(sharedPrefs.getInt("count_played", 108)) }

    // Vinyl spinning animation
    val infiniteTransition = rememberInfiniteTransition(label = "vinyl_transition")
    val spinningRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "vinyl_rotation"
    )
    
    val displayRotation = if (isPlaying) spinningRotation else 0f

    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            while (isPlaying) {
                kotlinx.coroutines.delay(4000)
                countPlayed += 1
                sharedPrefs.edit().putInt("count_played", countPlayed).apply()
            }
        }
    }

    val selectedStream = streams.first { it.id == selectedStreamId }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Máy Niệm Phật",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif
                        )
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.background,
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.04f)
                        )
                    )
                )
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Player Display Area
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Máy Chuyên Niệm Hỷ Lạc",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        color = MaterialTheme.colorScheme.primary
                    )
                )
                Text(
                    text = "Duy trì chánh niệm vang vọng khắp gia đạo",
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontStyle = FontStyle.Italic,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier.padding(top = 4.dp, bottom = 20.dp),
                    textAlign = TextAlign.Center
                )

                // Vinyl representation
                Box(
                    modifier = Modifier
                        .size(180.dp)
                        .rotate(displayRotation)
                        .background(Color(0xFF212121), CircleShape)
                        .border(6.dp, Color(0xFFFFD54F).copy(alpha = 0.4f), CircleShape)
                        .border(1.dp, Color.Black, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    // Concentric lines of records
                    Box(modifier = Modifier.size(140.dp).border(1.dp, Color.White.copy(alpha = 0.05f), CircleShape))
                    Box(modifier = Modifier.size(110.dp).border(1.dp, Color.White.copy(alpha = 0.05f), CircleShape))
                    Box(modifier = Modifier.size(80.dp).border(1.dp, Color.White.copy(alpha = 0.05f), CircleShape))
                    
                    // Album sticker art
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .background(MaterialTheme.colorScheme.primary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.MusicNote,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Title info
                Text(
                    text = selectedStream.title,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        color = MaterialTheme.colorScheme.onBackground
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.testTag("current_chant_title")
                )
                Text(
                    text = selectedStream.source,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
                )

                // Playing cycle counters
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "Vòng lặp cộng đức: $countPlayed biến",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp).testTag("may_niem_counter")
                    )
                }
            }

            // Playlist Selection and Controller
            Column(
                modifier = Modifier.fillMaxWidth()
            ) {
                // Volume slider
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.VolumeUp,
                        contentDescription = "Âm lượng",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Slider(
                        value = volume,
                        onValueChange = { volume = it },
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(
                            activeTrackColor = MaterialTheme.colorScheme.primary,
                            thumbColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }

                // Chanting list selector
                Text(
                    text = "Lựa chọn dòng tâm thức",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    streams.forEach { stream ->
                        val isCurrent = stream.id == selectedStreamId
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedStreamId = stream.id
                                    isPlaying = true
                                    Toast.makeText(context, "Khởi động: ${stream.title}", Toast.LENGTH_SHORT).show()
                                },
                            colors = CardDefaults.cardColors(
                                containerColor = if (isCurrent) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                            ),
                            border = BorderStroke(
                                width = 1.dp,
                                color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = stream.title,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium
                                        )
                                    )
                                    Text(
                                        text = stream.source,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                        )
                                    )
                                }
                                if (isCurrent && isPlaying) {
                                    Icon(
                                        imageVector = Icons.Filled.VolumeUp,
                                        contentDescription = "Đang phát",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Huge Play/Pause Action Floating Button
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    FilledIconButton(
                        onClick = {
                            isPlaying = !isPlaying
                            if (isPlaying) {
                                Toast.makeText(context, "Khởi tụng gia trì chánh niệm pháp giới...", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Tạm nghỉ niệm tụng.", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier
                            .size(64.dp)
                            .testTag("play_pause_button"),
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = if (isPlaying) "Tạm dừng" else "Phát tụng",
                            modifier = Modifier.size(32.dp),
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                }
            }
        }
    }
}
