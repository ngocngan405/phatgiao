package com.example.ui.screens

import android.content.Context
import android.os.Vibrator
import android.widget.Toast
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrangHatScreen(
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val sharedPrefs = context.getSharedPreferences("trang_hat_prefs", Context.MODE_PRIVATE)
    
    var beadCount by remember { mutableStateOf(sharedPrefs.getInt("bead_count", 0)) }
    var totalBeadCycles by remember { mutableStateOf(sharedPrefs.getInt("bead_cycles", 0)) }
    
    // Animation for pulling bead
    var triggerPull by remember { mutableStateOf(false) }
    val rotationAngle by animateFloatAsState(
        targetValue = if (triggerPull) 360f / 108f else 0f,
        animationSpec = tween(durationMillis = 150, easing = LinearEasing),
        label = "bead_rotation",
        finishedListener = {
            triggerPull = false
        }
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Tràng Hạt Niệm Phật",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif
                        )
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại")
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            beadCount = 0
                            totalBeadCycles = 0
                            sharedPrefs.edit().putInt("bead_count", 0).putInt("bead_cycles", 0).apply()
                            Toast.makeText(context, "Đã khởi tạo lại tràng hạt!", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = "Reset")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.background,
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.05f)
                        )
                    )
                )
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Count Display Area
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1f)
            ) {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "A Di Đà Phật",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        color = MaterialTheme.colorScheme.primary
                    )
                )
                
                Text(
                    text = "Nhấp vào màn hình để lần hạt niệm Phật",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
                )

                Box(
                    modifier = Modifier
                        .size(180.dp)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.05f), CircleShape)
                        .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = beadCount.toString(),
                            style = MaterialTheme.typography.displayMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                fontFamily = FontFamily.Serif
                            ),
                            modifier = Modifier.testTag("bead_counter_text")
                        )
                        HorizontalDivider(
                            modifier = Modifier.width(60.dp).padding(vertical = 8.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                        )
                        Text(
                            text = "Vòng: $totalBeadCycles (108 hạt)",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                }
            }

            // Interactive Prayer Mala Representation
            Box(
                modifier = Modifier
                    .size(260.dp)
                    .clickable {
                        if (!triggerPull) {
                            triggerPull = true
                            
                            // Increment logic
                            if (beadCount >= 107) {
                                beadCount = 0
                                totalBeadCycles++
                                sharedPrefs.edit().putInt("bead_cycles", totalBeadCycles).apply()
                                Toast.makeText(context, "Hoàn tất một chuỗi tràng hạt 108 niệm!", Toast.LENGTH_SHORT).show()
                            } else {
                                beadCount++
                            }
                            sharedPrefs.edit().putInt("bead_count", beadCount).apply()
                            
                            // Haptic Feedback / Vibrator if available
                            try {
                                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                                if (vibrator.hasVibrator()) {
                                    vibrator.vibrate(50) // vibrate 50ms
                                }
                            } catch (e: Exception) {
                                // ignore
                            }
                        }
                    }
                    .weight(1.5f),
                contentAlignment = Alignment.Center
            ) {
                // Large main bead in the middle
                Box(
                    modifier = Modifier
                        .size(120.dp)
                        .scale(if (triggerPull) 0.95f else 1f)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(Color(0xFF8D6E63), Color(0xFF4E342E))
                            ),
                            CircleShape
                        )
                        .border(2.dp, Color(0xFFFFD54F).copy(alpha = 0.3f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.SelfImprovement,
                        contentDescription = null,
                        tint = Color.White.copy(alpha = 0.8f),
                        modifier = Modifier.size(48.dp)
                    )
                }

                // Rotating circle of small beads on string orbit
                Box(
                    modifier = Modifier
                        .size(220.dp)
                        .rotate(rotationAngle)
                        .border(1.dp, Color(0xFFFFD54F).copy(alpha = 0.2f), CircleShape)
                ) {
                    // Place 18 decorative beads around the orbit to represent the visual string
                    for (i in 0 until 18) {
                        val angleRad = (i * 20) * (Math.PI / 180f)
                        val radiusPx = 110f // corresponding to 220.dp circle
                        
                        Box(
                            modifier = Modifier
                                .size(16.dp)
                                .align(Alignment.Center)
                                .offset(
                                    x = (radiusPx * Math.cos(angleRad)).dp,
                                    y = (radiusPx * Math.sin(angleRad)).dp
                                )
                                .background(
                                    Brush.radialGradient(
                                        colors = listOf(Color(0xFFBCAAA4), Color(0xFF5D4037))
                                    ),
                                    CircleShape
                                )
                        )
                    }
                }
            }
            
            Text(
                text = "“Lần hạt trì danh tiêu nghiệp chướng,\nTịnh niệm Di Đà vãng Tây Phương.”",
                style = MaterialTheme.typography.bodySmall.copy(
                    fontStyle = FontStyle.Italic,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                    textAlign = TextAlign.Center
                ),
                modifier = Modifier.padding(top = 16.dp, bottom = 24.dp)
            )
        }
    }
}
