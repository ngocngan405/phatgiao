package com.example.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.BuddhaDeity
import com.example.ui.BuddhistViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TriChuListScreen(
    viewModel: BuddhistViewModel,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    
    val filteredDeities = remember(searchQuery) {
        if (searchQuery.isBlank()) {
            BuddhaDeity.list
        } else {
            BuddhaDeity.list.filter {
                it.name.contains(searchQuery, ignoreCase = true) || 
                it.title.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Phật & Bồ Tát",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif
                        )
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier.testTag("tri_chu_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Quay lại"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
        ) {
            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Tìm kiếm đức Phật, Bồ Tát...") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Tìm kiếm") },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Filled.Close, contentDescription = "Xóa")
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
                    .testTag("buddha_search_input"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.12f)
                ),
                singleLine = true
            )

            if (filteredDeities.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Filled.Spa,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f),
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Không tìm thấy kết quả phù hợp",
                            style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
                        )
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                        .testTag("buddha_grid_list"),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    items(filteredDeities) { deity ->
                        BuddhaDeityCard(
                            deity = deity,
                            onClick = {
                                viewModel.selectedBuddhaDeity.value = deity
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BuddhaDeityCard(
    deity: BuddhaDeity,
    onClick: () -> Unit
) {
    val gradientBrush = remember(deity.gradientColors) {
        val color1 = Color(android.graphics.Color.parseColor(deity.gradientColors[0]))
        val color2 = Color(android.graphics.Color.parseColor(deity.gradientColors[1]))
        Brush.verticalGradient(colors = listOf(color1.copy(alpha = 0.15f), color2.copy(alpha = 0.35f)))
    }
    
    val accentColor = remember(deity.gradientColors) {
        Color(android.graphics.Color.parseColor(deity.gradientColors[0]))
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(220.dp)
            .clickable(onClick = onClick)
            .testTag("buddha_card_${deity.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.3f)
                    .background(gradientBrush)
            ) {
                AsyncImage(
                    model = deity.imageUrl,
                    contentDescription = deity.name,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    onLoading = { /* Fallback background is gradient */ },
                    onError = { /* Fallback background is gradient */ }
                )
                
                // Subtle glowing gold circular halo background effect
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.radialGradient(
                                colors = listOf(Color(0xFFFFD54F).copy(alpha = 0.2f), Color.Transparent),
                                radius = 250f
                            )
                        )
                )

                // Corner aesthetic lotus petal icon
                Icon(
                    imageVector = Icons.Filled.Spa,
                    contentDescription = null,
                    tint = accentColor.copy(alpha = 0.3f),
                    modifier = Modifier
                        .size(36.dp)
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                )
            }
            
            // Name label area
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.7f)
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = deity.name,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center,
                        lineHeight = 18.sp
                    ),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BuddhaDetailScreen(
    deity: BuddhaDeity,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    
    // Shared count of recitations for this particular Buddha
    val sharedPrefs = context.getSharedPreferences("tri_chu_counts", Context.MODE_PRIVATE)
    var recitationCount by remember(deity.id) { 
        mutableStateOf(sharedPrefs.getInt("deity_${deity.id}", 0)) 
    }
    
    var isChantingSimulated by remember { mutableStateOf(false) }

    LaunchedEffect(isChantingSimulated) {
        if (isChantingSimulated) {
            kotlinx.coroutines.delay(3000)
            isChantingSimulated = false
        }
    }

    val themeColor = remember(deity.gradientColors) {
        Color(android.graphics.Color.parseColor(deity.gradientColors[0]))
    }
    val themeColorLight = remember(deity.gradientColors) {
        Color(android.graphics.Color.parseColor(deity.gradientColors[0])).copy(alpha = 0.12f)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Chi Tiết Tôn Tượng",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif
                        )
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier.testTag("buddha_detail_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Quay lại"
                        )
                    }
                },
                actions = {
                    // Sharing/Bookmark indicator placeholder
                    IconButton(onClick = {
                        Toast.makeText(context, "A Di Đà Phật. Đã gieo duyên lành kính ngưỡng!", Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(
                            imageVector = Icons.Filled.Favorite,
                            tint = Color.Red.copy(alpha = 0.8f),
                            contentDescription = "Thành kính ngưỡng vọng"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
        ) {
            // 1. Hero Image Header with beautiful glowing Aura
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(android.graphics.Color.parseColor(deity.gradientColors[0])).copy(alpha = 0.2f),
                                Color(android.graphics.Color.parseColor(deity.gradientColors[1])).copy(alpha = 0.5f)
                            )
                        )
                    )
            ) {
                AsyncImage(
                    model = deity.imageUrl,
                    contentDescription = deity.name,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                
                // Dark elegant bottom gradient to contrast text
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f)),
                                startY = 300f
                            )
                        )
                )

                // Concentric Halo Circles
                Box(
                    modifier = Modifier
                        .size(240.dp)
                        .align(Alignment.Center)
                        .border(1.dp, Color(0xFFFFD54F).copy(alpha = 0.2f), CircleShape)
                        .border(3.dp, Color(0xFFFFD54F).copy(alpha = 0.1f), CircleShape)
                )

                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(24.dp)
                ) {
                    Text(
                        text = deity.title,
                        color = Color(0xFFFFD54F),
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = deity.name,
                        color = Color.White,
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif
                        )
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // 2. Recitation Counter Card (Interactive Practice!)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 20.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = themeColorLight),
                    border = BorderStroke(1.dp, themeColor.copy(alpha = 0.25f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Công đức trì chú",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = themeColor
                                )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text(
                                    text = recitationCount.toString(),
                                    style = MaterialTheme.typography.displaySmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Serif,
                                        color = themeColor
                                    ),
                                    modifier = Modifier.testTag("recitation_counter_text")
                                )
                                Text(
                                    text = " biến",
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                    ),
                                    modifier = Modifier.padding(bottom = 6.dp)
                                )
                            }
                        }
                        
                        Button(
                            onClick = {
                                recitationCount++
                                sharedPrefs.edit().putInt("deity_${deity.id}", recitationCount).apply()
                                Toast.makeText(context, "A Di Đà Phật. Trì chú tinh tấn!", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = themeColor),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("recitation_increment_button")
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Trì Chú", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // 3. Sacred Mantra Box (Mantra & Dhāranī)
                Text(
                    text = "Thần Chú & Chân Ngôn",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        color = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 24.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Filled.FormatQuote,
                            contentDescription = null,
                            tint = themeColor.copy(alpha = 0.2f),
                            modifier = Modifier.size(36.dp)
                        )
                        
                        Text(
                            text = deity.mantra,
                            style = MaterialTheme.typography.bodyLarge.copy(
                                fontStyle = FontStyle.Italic,
                                fontFamily = FontFamily.Serif,
                                lineHeight = 26.sp,
                                textAlign = TextAlign.Center,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            ),
                            modifier = Modifier
                                .padding(vertical = 12.dp)
                                .testTag("buddha_mantra_text")
                        )
                        
                        if (deity.mantraSanskrit.isNotEmpty()) {
                            Text(
                                text = "Sanskrit: ${deity.mantraSanskrit}",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontStyle = FontStyle.Italic,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                    textAlign = TextAlign.Center
                                ),
                                modifier = Modifier.padding(bottom = 16.dp)
                            )
                        }

                        HorizontalDivider(
                            modifier = Modifier.padding(vertical = 12.dp),
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            TextButton(
                                onClick = {
                                    clipboardManager.setText(AnnotatedString(deity.mantra))
                                    Toast.makeText(context, "Đã sao chép thần chú vào bộ nhớ!", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.testTag("copy_mantra_button")
                            ) {
                                Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Sao chép")
                            }

                            TextButton(
                                onClick = {
                                    isChantingSimulated = true
                                    Toast.makeText(context, "Đang khởi tạo chuông mõ gia trì thần chú...", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.testTag("listen_mantra_button")
                            ) {
                                Icon(
                                    imageVector = if (isChantingSimulated) Icons.Filled.VolumeUp else Icons.Filled.PlayArrow,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (isChantingSimulated) "Đang trì niệm..." else "Nghe tụng")
                            }
                        }
                    }
                }

                // 4. Biography Section
                Text(
                    text = "Tiểu Sử & Sự Tích",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        color = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.padding(bottom = 10.dp)
                )
                
                Text(
                    text = deity.biography,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        lineHeight = 24.sp,
                        fontFamily = FontFamily.Serif,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f),
                        textAlign = TextAlign.Justify
                    ),
                    modifier = Modifier
                        .padding(bottom = 24.dp)
                        .testTag("buddha_biography_text")
                )

                // 5. Great Vows Section
                Text(
                    text = "Đại Nguyện Vĩ Đại",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        color = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                deity.vows.forEachIndexed { index, vow ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .background(themeColorLight, CircleShape)
                                    .border(1.dp, themeColor.copy(alpha = 0.4f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = (index + 1).toString(),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = themeColor
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = vow,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    lineHeight = 20.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
