package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.data.*
import com.example.data.api.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ChatMessage(
    val sender: String, // "user" or "ai"
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

class BuddhistViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: BuddhistRepository

    // Preferences and Account settings
    private val sharedPrefs = application.getSharedPreferences("buddhist_prefs", Context.MODE_PRIVATE)
    val isDarkTheme = MutableStateFlow(sharedPrefs.getBoolean("is_dark_theme", true))
    
    val isLoggedIn = MutableStateFlow(sharedPrefs.getBoolean("is_logged_in", true))
    val userName = MutableStateFlow(sharedPrefs.getString("user_name", "Huỳnh Phúc Hải") ?: "Huỳnh Phúc Hải")
    val userPhone = MutableStateFlow(sharedPrefs.getString("user_phone", "") ?: "")
    val userEmail = MutableStateFlow(sharedPrefs.getString("user_email", "") ?: "")
    val userAuthMethod = MutableStateFlow(sharedPrefs.getString("user_auth_method", "Mặc định") ?: "Mặc định")

    fun toggleDarkTheme(isDark: Boolean) {
        isDarkTheme.value = isDark
        sharedPrefs.edit().putBoolean("is_dark_theme", isDark).apply()
    }

    fun registerAccount(name: String, email: String, phone: String, method: String) {
        sharedPrefs.edit().apply {
            putBoolean("is_logged_in", true)
            putString("user_name", name)
            putString("user_email", email)
            putString("user_phone", phone)
            putString("user_auth_method", method)
            apply()
        }
        isLoggedIn.value = true
        userName.value = name
        userEmail.value = email
        userPhone.value = phone
        userAuthMethod.value = method
    }

    fun logoutAccount() {
        sharedPrefs.edit().apply {
            putBoolean("is_logged_in", false)
            putString("user_name", "")
            putString("user_email", "")
            putString("user_phone", "")
            putString("user_auth_method", "")
            apply()
        }
        isLoggedIn.value = false
        userName.value = ""
        userEmail.value = ""
        userPhone.value = ""
        userAuthMethod.value = ""
    }

    // Search query states
    val scriptureQuery = MutableStateFlow("")
    val lectureQuery = MutableStateFlow("")

    // Bottom Navigation State
    val currentTab = MutableStateFlow("home") // "home", "calendar", "meditation", "scriptures", "profile"

    // Detail UI States
    val selectedScripture = MutableStateFlow<Scripture?>(null)
    val selectedLecture = MutableStateFlow<VideoLecture?>(null)
    val selectedImage = MutableStateFlow<BuddhistImage?>(null)
    val selectedBuddhaDeity = MutableStateFlow<BuddhaDeity?>(null)

    // Reading customization
    val fontSizeMultiplier = MutableStateFlow(1.0f) // Scale scripture text

    // AI Chat State
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                sender = "ai",
                text = "A Di Đà Phật. Kính chào đạo hữu, Thiền Am xin nguyện cầu bình an, tĩnh tại và hỷ xả luôn đong đầy nơi tâm đạo hữu. Hôm nay đạo hữu có điều gì cần đàm đạo, tìm hiểu về Phật pháp hay chia sẻ gánh nặng tâm tư chăng?"
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isChatLoading = MutableStateFlow(false)
    val isChatLoading: StateFlow<Boolean> = _isChatLoading.asStateFlow()

    private val _chatError = MutableStateFlow<String?>(null)
    val chatError: StateFlow<String?> = _chatError.asStateFlow()

    init {
        val database = BuddhistDatabase.getDatabase(application)
        repository = BuddhistRepository(database.buddhistDao())

        // Seed initial data asynchronously
        viewModelScope.launch {
            repository.initializeDefaultDataIfNeeded()
        }
    }

    // --- Reactive Data Streams with Filtering ---
    val scriptures: StateFlow<List<Scripture>> = scriptureQuery
        .debounce(200)
        .flatMapLatest { query ->
            if (query.isBlank()) {
                repository.allScriptures
            } else {
                repository.searchScriptures(query)
            }
        }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val videoLectures: StateFlow<List<VideoLecture>> = lectureQuery
        .debounce(200)
        .flatMapLatest { query ->
            if (query.isBlank()) {
                repository.allVideoLectures
            } else {
                repository.searchVideoLectures(query)
            }
        }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val events: StateFlow<List<BuddhistEvent>> = repository.allEvents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val images: StateFlow<List<BuddhistImage>> = repository.allImages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())


    // --- Actions ---

    fun toggleScriptureBookmark(id: Int, isBookmarked: Boolean) {
        viewModelScope.launch {
            repository.updateScriptureBookmark(id, isBookmarked)
            // Update active state if selected
            selectedScripture.value?.let {
                if (it.id == id) {
                    selectedScripture.value = it.copy(isBookmarked = isBookmarked)
                }
            }
        }
    }

    fun saveScriptureNotes(id: Int, notes: String) {
        viewModelScope.launch {
            repository.updateScriptureNotes(id, notes)
            selectedScripture.value?.let {
                if (it.id == id) {
                    selectedScripture.value = it.copy(userNotes = notes)
                }
            }
        }
    }

    fun toggleLectureFavorite(id: String, isFavorite: Boolean) {
        viewModelScope.launch {
            repository.updateLectureFavorite(id, isFavorite)
            selectedLecture.value?.let {
                if (it.id == id) {
                    selectedLecture.value = it.copy(isFavorite = isFavorite)
                }
            }
        }
    }

    fun recordLectureView(id: String) {
        viewModelScope.launch {
            repository.incrementLectureViews(id)
        }
    }

    fun toggleEventReminder(id: Int, isReminderSet: Boolean) {
        viewModelScope.launch {
            repository.updateEventReminder(id, isReminderSet)
        }
    }

    fun toggleImageLiked(id: Int, isLiked: Boolean) {
        viewModelScope.launch {
            repository.updateImageLiked(id, isLiked)
            selectedImage.value?.let {
                if (it.id == id) {
                    selectedImage.value = it.copy(isLiked = isLiked)
                }
            }
        }
    }

    fun adjustFontSize(increment: Boolean) {
        val current = fontSizeMultiplier.value
        val next = if (increment) current + 0.1f else current - 0.1f
        fontSizeMultiplier.value = next.coerceIn(0.7f, 2.0f)
    }

    // --- AI Chat Logic via Gemini ---

    fun sendChatMessage(text: String) {
        if (text.isBlank()) return

        val userMsg = ChatMessage(sender = "user", text = text)
        _chatMessages.value = _chatMessages.value + userMsg
        _isChatLoading.value = true
        _chatError.value = null

        viewModelScope.launch {
            try {
                val apiKey = BuildConfig.GEMINI_API_KEY
                
                // System Instruction to make Gemini respond with deep Buddhist tranquility and wisdom
                val systemPrompt = """
                    Bạn là Trợ lý Phật Pháp AI tĩnh tại, thông thái, mang danh hiệu 'Thiền Am'. 
                    Bạn chia sẻ giáo lý Phật giáo Việt Nam, lời Phật dạy (Kinh Pháp Cú, các kinh điển Đại Thừa, nguyên thủy, các bài thuyết pháp của Thiền sư Thích Nhất Hạnh, Thầy Thích Pháp Hòa, Thiền sư Minh Niệm, v.v.), giải đáp thắc mắc về cuộc sống, tu tập thiền định, hóa giải muộn phiền bằng lòng từ bi, hỷ xả, ái ngữ và thấu hiểu sâu sắc.
                    
                    YÊU CẦU QUAN TRỌNG:
                    1. Giọng văn của bạn phải cực kỳ an tĩnh, dịu nhẹ, thanh thoát giống như không gian tĩnh lặng của một ngôi chùa cổ Việt Nam lúc sớm mai.
                    2. Luôn xưng hô tôn kính và khiêm tốn: dùng từ "Thiền Am" để xưng và gọi người dùng là "đạo hữu" một cách trân quý. Hoặc thỉnh thoảng niệm "A Di Đà Phật" một cách nhẹ nhàng ở đầu hoặc cuối câu để bày tỏ sự chúc phúc tâm linh.
                    3. Đưa ra lời khuyên thiết thực theo triết lý Phật giáo (như chánh niệm, nhân quả, duyên khởi, vô thường, quán chiếu hơi thở) giúp người dùng chuyển hóa đau khổ, vượt lên trên phiền não cuộc sống.
                    4. Trả lời súc tích, tinh tế bằng tiếng Việt chuẩn xác. Tránh tranh luận giáo lý cao siêu gây chia rẽ, hướng người dùng về việc quay lại chánh niệm trong giây phút hiện tại.
                """.trimIndent()

                // Compile history for context
                val contents = _chatMessages.value.takeLast(10).map { msg ->
                    Content(parts = listOf(Part(text = if (msg.sender == "user") "Đạo hữu: ${msg.text}" else "Thiền Am: ${msg.text}")))
                }

                val request = GenerateContentRequest(
                    contents = contents,
                    systemInstruction = Content(parts = listOf(Part(text = systemPrompt))),
                    generationConfig = GenerationConfig(temperature = 0.7f)
                )

                val response = withContext(Dispatchers.IO) {
                    RetrofitClient.service.generateContent(apiKey, request)
                }

                val aiText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    ?: "A Di Đà Phật, Thiền Am đang tĩnh tâm chiêm nghiệm câu hỏi của đạo hữu nhưng kết nối chưa thông suốt. Xin đạo hữu từ bi mở rộng lòng hoan hỷ thử lại sau."

                _chatMessages.value = _chatMessages.value + ChatMessage(sender = "ai", text = aiText)
            } catch (e: Exception) {
                _chatError.value = "Không thể kết nối đến Trợ lý AI Phật Pháp. Xin kiểm tra kết nối mạng và thử lại."
                _chatMessages.value = _chatMessages.value + ChatMessage(
                    sender = "ai",
                    text = "A Di Đà Phật. Có một chút chướng ngại kết nối mạng trên nẻo đường truyền Phật pháp. Đạo hữu hoan hỷ xem lại kết nối Internet nhé."
                )
            } finally {
                _isChatLoading.value = false
            }
        }
    }

    fun clearChat() {
        _chatMessages.value = listOf(
            ChatMessage(
                sender = "ai",
                text = "A Di Đà Phật. Thiền Am đã thanh lọc tâm tư hội thoại. Lòng ta lại sạch trong như đóa sen sớm mai. Đạo hữu có điều gì muốn sẻ chia chăng?"
            )
        )
        _chatError.value = null
    }
}
