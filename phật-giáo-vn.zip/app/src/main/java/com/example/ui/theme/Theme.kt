package com.example.ui.theme

import android.os.Build
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = SaffronLight,
    onPrimary = AncientWood,
    secondary = LotusSoft,
    onSecondary = AncientWood,
    tertiary = SageGreen,
    onTertiary = AncientWood,
    background = AncientWood,
    onBackground = LightText,
    surface = WoodMedium,
    onSurface = LightText,
    surfaceVariant = ShadowGold,
    onSurfaceVariant = LightText
  )

private val LightColorScheme =
  lightColorScheme(
    primary = SaffronGold,
    onPrimary = PureBeige,
    secondary = LotusPink,
    onSecondary = PureBeige,
    tertiary = ForestGreen,
    onTertiary = PureBeige,
    background = IncenseBeige,
    onBackground = DarkText,
    surface = PureBeige,
    onSurface = DarkText,
    surfaceVariant = Color(0xFFF2EBE0),
    onSurfaceVariant = DarkText
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Dynamic color is available on Android 12+
  dynamicColor: Boolean = true,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
