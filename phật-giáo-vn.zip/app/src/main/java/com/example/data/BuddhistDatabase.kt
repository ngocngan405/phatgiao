package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        Scripture::class,
        VideoLecture::class,
        BuddhistEvent::class,
        BuddhistImage::class
    ],
    version = 1,
    exportSchema = false
)
abstract class BuddhistDatabase : RoomDatabase() {
    abstract fun buddhistDao(): BuddhistDao

    companion object {
        @Volatile
        private var INSTANCE: BuddhistDatabase? = null

        fun getDatabase(context: Context): BuddhistDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BuddhistDatabase::class.java,
                    "buddhist_sharing_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
