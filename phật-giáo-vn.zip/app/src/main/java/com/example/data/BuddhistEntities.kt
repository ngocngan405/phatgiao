package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "scriptures")
data class Scripture(
    @PrimaryKey val id: Int,
    val title: String,
    val category: String,
    val shortDesc: String,
    val content: String,
    val isBookmarked: Boolean = false,
    val userNotes: String = ""
)

@Entity(tableName = "video_lectures")
data class VideoLecture(
    @PrimaryKey val id: String,
    val title: String,
    val teacher: String,
    val duration: String,
    val videoUrl: String,
    val thumbnailUrl: String,
    val shortDesc: String,
    val isFavorite: Boolean = false,
    val viewsCount: Int = 0
)

@Entity(tableName = "buddhist_events")
data class BuddhistEvent(
    @PrimaryKey val id: Int,
    val title: String,
    val solarDate: String, // Solar date (e.g. 15/05/2026)
    val lunarDate: String, // Lunar date (e.g. 15/04 Âm Lịch)
    val category: String,  // Lễ lớn, Lễ vía, Sự kiện khác
    val description: String,
    val isReminderSet: Boolean = false
)

@Entity(tableName = "buddhist_images")
data class BuddhistImage(
    @PrimaryKey val id: Int,
    val title: String,
    val imageUrl: String,
    val description: String,
    val isLiked: Boolean = false
)
