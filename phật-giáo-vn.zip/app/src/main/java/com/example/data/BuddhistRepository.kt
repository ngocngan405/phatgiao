package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map

class BuddhistRepository(private val buddhistDao: BuddhistDao) {

    val allScriptures: Flow<List<Scripture>> = buddhistDao.getAllScriptures()
    val allVideoLectures: Flow<List<VideoLecture>> = buddhistDao.getAllVideoLectures()
    val allEvents: Flow<List<BuddhistEvent>> = buddhistDao.getAllEvents()
    val allImages: Flow<List<BuddhistImage>> = buddhistDao.getAllImages()

    fun getScriptureById(id: Int): Flow<Scripture?> = buddhistDao.getScriptureById(id)
    fun searchScriptures(query: String): Flow<List<Scripture>> = buddhistDao.searchScriptures(query)

    fun getVideoLectureById(id: String): Flow<VideoLecture?> = buddhistDao.getVideoLectureById(id)
    fun searchVideoLectures(query: String): Flow<List<VideoLecture>> = buddhistDao.searchVideoLectures(query)

    suspend fun updateScriptureBookmark(id: Int, isBookmarked: Boolean) =
        buddhistDao.updateScriptureBookmark(id, isBookmarked)

    suspend fun updateScriptureNotes(id: Int, notes: String) =
        buddhistDao.updateScriptureNotes(id, notes)

    suspend fun updateLectureFavorite(id: String, isFavorite: Boolean) =
        buddhistDao.updateLectureFavorite(id, isFavorite)

    suspend fun incrementLectureViews(id: String) =
        buddhistDao.incrementLectureViews(id)

    suspend fun updateEventReminder(id: Int, isReminderSet: Boolean) =
        buddhistDao.updateEventReminder(id, isReminderSet)

    suspend fun updateImageLiked(id: Int, isLiked: Boolean) =
        buddhistDao.updateImageLiked(id, isLiked)

    suspend fun initializeDefaultDataIfNeeded() {
        // Prepopulate scriptures if empty
        val currentScriptures = buddhistDao.getAllScriptures().first()
        if (currentScriptures.isEmpty()) {
            val defaultScriptures = listOf(
                Scripture(
                    id = 1,
                    title = "Bát Nhã Ba La Mật Đa Tâm Kinh",
                    category = "Kinh Đại Thừa",
                    shortDesc = "Kinh điển cốt lõi về Tánh Không (Sunyata) trong Phật giáo Đại Thừa, soi sáng con đường vượt qua mọi khổ đau ách nạn.",
                    content = """
                        Khi Bồ Tát Quán Tự Tại hành sâu vào Bát Nhã Ba La Mật Đa, Ngài soi sáng thấy năm uẩn đều Không, liền độ thoát hết thảy khổ ách.

                        Này Xá Lợi Tử! Sắc chẳng khác Không, Không chẳng khác Sắc. Sắc tức là Không, Không tức là Sắc. Thụ, Tưởng, Hành, Thức cũng đều như thế.

                        Này Xá Lợi Tử! Tướng “Không” của mọi pháp ấy: Không sinh, không diệt, không nhơ, không sạch, không thêm, không bớt.

                        Cho nên trong cái “Không” ấy:
                        - Không có Sắc, không có Thụ, Tưởng, Hành, Thức.
                        - Không có Mắt, Tai, Mũi, Lưỡi, Thân, Ý; không có Sắc, Thanh, Hương, Vị, Xúc, Pháp.
                        - Không có nhãn giới, cho đến không có ý thức giới.
                        - Không có vô minh, cũng không có cái hết vô minh; cho đến không có già chết, cũng không có cái hết già chết.
                        - Không có Khổ, Tập, Diệt, Đạo; không có Trí tuệ, cũng không có Chứng đắc.

                        Vì không có chỗ chứng đắc, Bồ Tát y theo Bát Nhã Ba La Mật Đa, lòng không ngăn ngại. Vì lòng không ngăn ngại nên không sợ hãi, xa lìa điên đảo mộng tưởng, đạt tới cứu cánh Niết Bàn.

                        Chư Phật ba đời cũng y theo Bát Nhã Ba La Mật Đa mà đắc quả Vô Thượng Chánh Đẳng Chánh Giác.

                        Nên biết Bát Nhã Ba La Mật Đa là đại thần chú, là đại minh chú, là vô thượng chú, là vô đẳng đẳng chú, có thể trừ diệt hết thảy khổ đau, chân thật không dối.

                        Vì thế nói chú Bát Nhã Ba La Mật Đa, liền nói chú rằng:
                        "Yết đế, yết đế, ba la yết đế, ba la tăng yết đế, bồ đề tát bà ha."
                    """.trimIndent()
                ),
                Scripture(
                    id = 2,
                    title = "Kinh Từ Bi (Metta Sutta)",
                    category = "Kinh Căn Bản",
                    shortDesc = "Lời dạy của Đức Phật về việc nuôi dưỡng lòng từ bi vô lượng, rải tình thương yêu đến muôn loài vạn vật không biên giới.",
                    content = """
                        Những ai mong cầu an lạc, mong đạt tới tịch tĩnh Niết Bàn, cần phải có năng lực, ngay thẳng, chí trực, nhu hòa, khiêm tốn, không kiêu mạn.

                        Biết sống tri túc, giản đơn, ít bận rộn, tự chủ, hộ trì các căn, sáng suốt và không bám víu vào gia đình quyến thuộc.

                        Đừng làm bất cứ việc gì nhỏ mọn khiến cho các bậc hiền giả phê phán. Hãy luôn nguyện ước: "Nguyện cho muôn loài vạn vật được an lành, hạnh phúc và bình yên."

                        Bất kỳ chúng sinh nào đang sống:
                        - Kẻ yếu hay người mạnh, kẻ phàm phu hay bậc thánh nhân,
                        - Chúng sinh to lớn hay bé nhỏ, trung bình hay khổng lồ,
                        - Chúng sinh có thể nhìn thấy hay không thể nhìn thấy, sống gần hay sống xa, đã sinh ra hay đang chờ sinh nở...
                        Nguyện cho tất cả đều được tràn ngập niềm an lạc hạnh phúc.

                        Đừng lừa dối người khác, đừng khinh rẻ bất cứ ai ở bất cứ nơi nào. Cũng đừng vì giận hờn hay ác tâm mà mong cho người khác gặp đau khổ ách nạn.

                        Như người mẹ hiến dâng cuộc sống để bảo vệ đứa con duy nhất của mình, ta hãy mở rộng lòng thương yêu vô lượng đến muôn loài vạn vật khắp thế gian.

                        Hãy lan tỏa lòng từ bi rộng lớn khắp vũ trụ, từ trên cao, dưới thấp và xung quanh, không một chút chướng ngại, không một lòng oán ghét, thù hận.

                        Dù khi đang đứng, đang đi, đang ngồi hay đang nằm, miễn là còn tỉnh thức, hãy luôn an trú trong chánh niệm từ bi này. Đây chính là cách sống cao thượng nhất ngay trong cuộc đời này.
                    """.trimIndent()
                ),
                Scripture(
                    id = 3,
                    title = "Kinh Pháp Cú (Tuyển Chọn Ý Nghĩa)",
                    category = "Kinh Tiểu Bộ",
                    shortDesc = "Tổng hợp những lời dạy ngắn gọn, súc tích bằng kệ ngôn của Đức Phật hướng dẫn tâm ý và đời sống tỉnh thức.",
                    content = """
                        Kệ Pháp Cú số 1 & 2:
                        "Trong các pháp, tâm dẫn đầu, tâm làm chủ, tâm tạo tác. Nếu nói hoặc làm với tâm ô nhiễm, đau khổ sẽ theo sau như bánh xe lăn theo chân con vật kéo."
                        "Trong các pháp, tâm dẫn đầu, tâm làm chủ, tâm tạo tác. Nếu nói hoặc làm với tâm thanh tịnh, hạnh phúc sẽ theo sau như hình với bóng."

                        Kệ Pháp Cú số 3 & 4:
                        "Họ mắng tôi, đánh tôi, thắng tôi, cướp của tôi. Ai còn ôm hiềm hận ấy, hận thù không thể nguôi."
                        "Họ mắng tôi, đánh tôi, thắng tôi, cướp của tôi. Ai không ôm hiềm hận ấy, hận thù tự nhiên nguôi."

                        Kệ Pháp Cú số 5:
                        "Với hận diệt hận thù, đời này không có được. Từ bi diệt hận thù, là định luật nghìn thu."

                        Kệ Pháp Cú số 50:
                        "Không nên nhìn lỗi người, không nhìn chuyện người làm hay chưa làm. Chỉ nên nhìn hành động của chính mình, xem đã làm hay chưa làm."

                        Kệ Pháp Cú số 103:
                        "Dù tại chiến trường, thắng hàng vạn quân thù, tự thắng mình mới là chiến công oanh liệt nhất."

                        Kệ Pháp Cú số 165:
                        "Tự mình làm điều ác, tự mình làm nhiễm ô. Tự mình tránh điều ác, tự mình làm thanh tịnh. Thanh tịnh hay nhiễm ô đều do tự mình, không ai có thể làm người khác thanh tịnh."
                    """.trimIndent()
                ),
                Scripture(
                    id = 4,
                    title = "Kinh Di Đà Pháp Bảo",
                    category = "Kinh Đại Thừa",
                    shortDesc = "Kinh tụng giới thiệu về cảnh giới Cực Lạc Tây Phương trang nghiêm thanh tịnh của Đức Phật A Di Đà và phương pháp trì danh niệm Phật.",
                    content = """
                        Ta nghe như thế này: Một thời Đức Phật ở vườn Kỳ Thọ, Cấp Cô Độc, nước Xá Vệ, cùng với một nghìn hai trăm năm mươi vị Đại Tỳ Kheo câu hội.

                        Bấy giờ, Đức Phật bảo Trưởng lão Xá Lợi Phất rằng: "Từ đây đi về hướng Tây qua mười muôn ức cõi Phật, có một thế giới tên là Cực Lạc. Cõi đó có Đức Phật hiệu là A Di Đà hiện đang thuyết pháp."

                        Xá Lợi Phất! Vì sao cõi đó tên là Cực Lạc? Vì chúng sinh trong cõi đó không có những sự khổ, chỉ hưởng những sự vui, nên tên là Cực Lạc.

                        Lại nữa, cõi Cực Lạc có bảy lớp lan can, bảy lớp lưới giăng, bảy lớp hàng cây, đều bằng bốn chất báu bao bọc chung quanh, vì thế nên cõi đó tên là Cực Lạc.

                        Lại nữa, cõi Cực Lạc có ao bằng bảy chất báu, nước tám công đức tràn đầy trong ao, đáy ao thuần dùng cát vàng trải làm đất. Bốn bên đường đi bằng vàng, bạc, lưu ly, pha lê hiệp thành.

                        Chúng sinh nghe thấy như thế, nên phát nguyện sinh về cõi đó. Vì sao? Vì được cùng các bậc Thượng thiện nhân câu hội một chỗ.

                        Nếu có thiện nam tử, thiện nữ nhân nào nghe nói đến Đức Phật A Di Đà rồi chấp trì danh hiệu của Ngài, hoặc trong một ngày, hoặc hai ngày, đến bảy ngày, một lòng không xao lãng, thì khi lâm chung, Đức Phật A Di Đà cùng chư Thánh chúng hiện thân trước mặt người đó. Người đó tâm không điên đảo, liền được vãng sinh về cõi nước Cực Lạc của Đức Phật A Di Đà.
                    """.trimIndent()
                )
            )
            buddhistDao.insertScriptures(defaultScriptures)
        }

        // Prepopulate video lectures if empty
        val currentLectures = buddhistDao.getAllVideoLectures().first()
        if (currentLectures.isEmpty()) {
            val defaultLectures = listOf(
                VideoLecture(
                    id = "lecture_1",
                    title = "Nghệ Thuật Nhận Diện và Chuyển Hóa Đau Khổ",
                    teacher = "Thiền sư Thích Nhất Hạnh",
                    duration = "54:12",
                    videoUrl = "https://www.youtube.com/watch?v=dQw4w9WgXcQ", // Standard URL
                    thumbnailUrl = "https://images.unsplash.com/photo-1518241353330-0f7941c2d9b5?w=500", // Serene temple lamp
                    shortDesc = "Thiền sư chia sẻ phương pháp chánh niệm thực tế để ôm ấp nỗi đau, hiểu rõ gốc rễ đau khổ và chuyển hóa thành hiểu biết, tình thương sâu sắc.",
                    isFavorite = true,
                    viewsCount = 1250
                ),
                VideoLecture(
                    id = "lecture_2",
                    title = "Sống An Lạc Giữa Biến Động Đời Thường",
                    teacher = "Thầy Thích Pháp Hòa",
                    duration = "1:15:40",
                    videoUrl = "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
                    thumbnailUrl = "https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=500", // Meditation on beach/nature
                    shortDesc = "Những bài giảng hóm hỉnh, sâu sắc đầy thực tế của Thầy Thích Pháp Hòa giúp người cư sĩ Phật tử tìm được chốn bình yên, tĩnh tại ngay trong những lo toan gia đình và công việc.",
                    isFavorite = false,
                    viewsCount = 3420
                ),
                VideoLecture(
                    id = "lecture_3",
                    title = "Hiểu Về Trái Tim và Trị Liệu Tâm Hồn",
                    teacher = "Thiền sư Thích Minh Niệm",
                    duration = "45:18",
                    videoUrl = "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
                    thumbnailUrl = "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=500", // Serene yoga/meditation zen
                    shortDesc = "Trích chuỗi bài giảng tâm lý trị liệu sâu sắc hướng dẫn cách chữa lành các vết thương lòng, vượt qua trầm cảm, lo âu thông qua thiền Vipassana bản xứ.",
                    isFavorite = true,
                    viewsCount = 2890
                ),
                VideoLecture(
                    id = "lecture_4",
                    title = "Ý Nghĩa Nhân Quả và Nghiệp Báo trong Đời Sống",
                    teacher = "Hoà thượng Thích Trí Quảng",
                    duration = "1:02:05",
                    videoUrl = "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
                    thumbnailUrl = "https://images.unsplash.com/photo-1609137144813-92f76ccb5299?w=500", // Incense burner
                    shortDesc = "Đại trưởng lão phân tích chi tiết quy luật nhân quả vận hành, giúp Phật tử có cái nhìn đúng đắn để gieo trồng phước báo, tránh xa ác nghiệp bảo vệ gia đình.",
                    isFavorite = false,
                    viewsCount = 980
                )
            )
            buddhistDao.insertVideoLectures(defaultLectures)
        }

        // Prepopulate events if empty
        val currentEvents = buddhistDao.getAllEvents().first()
        if (currentEvents.isEmpty()) {
            val defaultEvents = listOf(
                BuddhistEvent(
                    id = 1,
                    title = "Lễ Thượng Nguyên (Rằm Tháng Giêng)",
                    solarDate = "02/03/2026",
                    lunarDate = "15/01 Rằm đầu năm",
                    category = "Lễ Lớn",
                    description = "Đại lễ cầu an đầu năm cho bản thân và gia quyến, tụng kinh Dược Sư, phát nguyện làm lành lánh dữ suốt cả năm.",
                    isReminderSet = false
                ),
                BuddhistEvent(
                    id = 2,
                    title = "Đại Lễ Phật Đản (Vesak)",
                    solarDate = "31/05/2026",
                    lunarDate = "15/04 Kỷ niệm Đức Phật Đản Sinh",
                    category = "Đại Lễ Quốc Tế",
                    description = "Đại lễ kỷ niệm ngày sinh của Đức Phật Thích Ca Mâu Ni. Nghi thức tắm Phật thiêng liêng, thả hoa đăng cầu nguyện hòa bình thế giới.",
                    isReminderSet = true
                ),
                BuddhistEvent(
                    id = 3,
                    title = "Đại Lễ Vu Lan Báo Hiếu",
                    solarDate = "27/08/2026",
                    lunarDate = "15/07 Rằm Tháng Bảy",
                    category = "Đại Lễ Truyền Thống",
                    description = "Mùa tri ân đấng sinh thành dưỡng dục. Nghi thức cài hoa hồng đỏ/trắng thiêng liêng, tụng kinh báo hiếu cha mẹ siêu độ tổ tiên.",
                    isReminderSet = false
                ),
                BuddhistEvent(
                    id = 4,
                    title = "Lễ Vía Quán Thế Âm Bồ Tát Khánh Đản",
                    solarDate = "06/04/2026",
                    lunarDate = "19/02 Ngày vía Đản sinh",
                    category = "Lễ Vía",
                    description = "Tưởng niệm công đức từ bi cứu khổ cứu nạn vô lượng của Mẹ Hiền Quán Thế Âm. Phật tử trì tụng chú Đại Bi và hồng danh Ngài.",
                    isReminderSet = false
                ),
                BuddhistEvent(
                    id = 5,
                    title = "Lễ Vía Phật A Di Đà Khánh Đản",
                    solarDate = "26/12/2026",
                    lunarDate = "17/11 Ngày Vía Phật A Di Đà",
                    category = "Lễ Vía",
                    description = "Kỷ niệm khánh đản Đức Từ Phụ A Di Đà - Giáo chủ cõi Tây Phương Cực Lạc. Khóa tu niệm Phật chuyên ròng cầu nguyện vãng sinh.",
                    isReminderSet = false
                )
            )
            buddhistDao.insertEvents(defaultEvents)
        }

        // Prepopulate images if empty
        val currentImages = buddhistDao.getAllImages().first()
        if (currentImages.isEmpty()) {
            val defaultImages = listOf(
                BuddhistImage(
                    id = 1,
                    title = "Sen Hồng Tịnh Độ",
                    imageUrl = "https://images.unsplash.com/photo-1528183429752-a97d0bf99b5a?w=800",
                    description = "Đóa hoa sen vươn lên từ bùn nhơ mà không hôi tanh, đại diện cho bản tính thanh tịnh thanh khiết sẵn có nơi mỗi chúng sinh.",
                    isLiked = true
                ),
                BuddhistImage(
                    id = 2,
                    title = "Mặt Phật Bình Yên",
                    imageUrl = "https://images.unsplash.com/photo-1542382156909-9ae37b3f56fd?w=800",
                    description = "Nụ cười mỉm từ bi sâu thẳm của Đức Thế Tôn, xua tan muôn vàn phiền não mệt mỏi lo toan của cuộc sống thường nhật.",
                    isLiked = false
                ),
                BuddhistImage(
                    id = 3,
                    title = "Mái Chùa Cổ Kính Trong Sương",
                    imageUrl = "https://images.unsplash.com/photo-1504618223053-559bdef9dd5a?w=800",
                    description = "Mái chùa cong vút ẩn hiện trong sương sớm núi Yên Tử mộc mạc, tĩnh mịch đưa tâm hồn trở về nguyên sơ lặng lẽ.",
                    isLiked = false
                ),
                BuddhistImage(
                    id = 4,
                    title = "Ánh Đăng Lung Linh",
                    imageUrl = "https://images.unsplash.com/photo-1518241353330-0f7941c2d9b5?w=800",
                    description = "Ngọn đèn dầu ấm áp tỏa sáng nơi góc chánh điện tôn nghiêm, thắp sáng ngọn đuốc trí tuệ xua tan bóng tối vô minh.",
                    isLiked = true
                ),
                BuddhistImage(
                    id = 5,
                    title = "Lối Đi Thiền Hành",
                    imageUrl = "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=800",
                    description = "Con đường nhỏ xanh mát tre trúc quanh co uốn lượn dẫn vào khuôn viên chùa, thích hợp cho những bước chân thiền hành an lạc.",
                    isLiked = false
                ),
                BuddhistImage(
                    id = 6,
                    title = "Thiền Tọa Bình Minh",
                    imageUrl = "https://images.unsplash.com/photo-1545128485-c400e7702796?w=800",
                    description = "Hình bóng chư tăng tĩnh lặng tọa thiền đón nhận những tia nắng ấm áp đầu tiên gột rửa thân tâm thanh tịnh.",
                    isLiked = false
                )
            )
            buddhistDao.insertImages(defaultImages)
        }
    }
}
