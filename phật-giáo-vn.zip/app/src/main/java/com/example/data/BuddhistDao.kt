package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface BuddhistDao {

    // --- Scriptures ---
    @Query("SELECT * FROM scriptures ORDER BY id ASC")
    fun getAllScriptures(): Flow<List<Scripture>>

    @Query("SELECT * FROM scriptures WHERE id = :id")
    fun getScriptureById(id: Int): Flow<Scripture?>

    @Query("SELECT * FROM scriptures WHERE title LIKE '%' || :query || '%' OR content LIKE '%' || :query || '%'")
    fun searchScriptures(query: String): Flow<List<Scripture>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScriptures(scriptures: List<Scripture>)

    @Query("UPDATE scriptures SET isBookmarked = :isBookmarked WHERE id = :id")
    suspend fun updateScriptureBookmark(id: Int, isBookmarked: Boolean)

    @Query("UPDATE scriptures SET userNotes = :notes WHERE id = :id")
    suspend fun updateScriptureNotes(id: Int, notes: String)


    // --- Video Lectures ---
    @Query("SELECT * FROM video_lectures ORDER BY viewsCount DESC")
    fun getAllVideoLectures(): Flow<List<VideoLecture>>

    @Query("SELECT * FROM video_lectures WHERE id = :id")
    fun getVideoLectureById(id: String): Flow<VideoLecture?>

    @Query("SELECT * FROM video_lectures WHERE title LIKE '%' || :query || '%' OR teacher LIKE '%' || :query || '%'")
    fun searchVideoLectures(query: String): Flow<List<VideoLecture>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVideoLectures(lectures: List<VideoLecture>)

    @Query("UPDATE video_lectures SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun updateLectureFavorite(id: String, isFavorite: Boolean)

    @Query("UPDATE video_lectures SET viewsCount = viewsCount + 1 WHERE id = :id")
    suspend fun incrementLectureViews(id: String)


    // --- Buddhist Events ---
    @Query("SELECT * FROM buddhist_events ORDER BY id ASC")
    fun getAllEvents(): Flow<List<BuddhistEvent>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvents(events: List<BuddhistEvent>)

    @Query("UPDATE buddhist_events SET isReminderSet = :isReminderSet WHERE id = :id")
    suspend fun updateEventReminder(id: Int, isReminderSet: Boolean)


    // --- Buddhist Images ---
    @Query("SELECT * FROM buddhist_images ORDER BY id ASC")
    fun getAllImages(): Flow<List<BuddhistImage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertImages(images: List<BuddhistImage>)

    @Query("UPDATE buddhist_images SET isLiked = :isLiked WHERE id = :id")
    suspend fun updateImageLiked(id: Int, isLiked: Boolean)
}
