package com.example.data

data class BuddhaDeity(
    val id: Int,
    val name: String,
    val title: String,
    val biography: String,
    val vows: List<String>,
    val mantra: String,
    val mantraSanskrit: String = "",
    val imageUrl: String,
    val gradientColors: List<String> // hex colors for background visual polish
) {
    companion object {
        val list = listOf(
            BuddhaDeity(
                id = 1,
                name = "Đức Phật Dược Sư",
                title = "Dược Sư Lưu Ly Quang Vương Như Lai",
                biography = "Đức Phật Dược Sư là vị giáo chủ của thế giới Tịnh Lưu Ly ở phương Đông. Ngài là đấng y vương vô lượng, thấu suốt tất cả y dược của thế gian và xuất thế gian, có thể chữa trị hết thảy thân bệnh và tâm bệnh, giúp chúng sinh giải thoát khỏi khổ đau luân hồi và bệnh tật hiểm nghèo.",
                vows = listOf(
                    "Thân thể quang minh lỗi lạc, soi chiếu vô số thế giới, giúp chúng sinh thân tướng trang nghiêm.",
                    "Hào quang lưu ly sáng sạch, dẫn dắt chúng sinh đang chìm đắm trong đêm tối tìm thấy nẻo sáng.",
                    "Ban bố trí tuệ phương tiện vô lượng, giúp chúng sinh thụ dụng đầy đủ không thiếu thốn.",
                    "Dẫn dắt những người tu theo tà đạo quay về với Chánh đạo bồ-đề thanh tịnh.",
                    "Giúp người tu hành giữ gìn giới luật trang nghiêm, nếu lỡ phạm giới nghe danh hiệu Ngài liền thanh tịnh.",
                    "Chữa lành các tật nguyền, đau đớn thể xác cho chúng sinh khi nghe và niệm danh hiệu Ngài.",
                    "Cứu giúp những người nghèo khổ, cô độc, không ai nuôi nấng, không nơi nương tựa được no đủ, an vui.",
                    "Giúp thân nữ nhân chuyển hóa những khổ đau ràng buộc để đạt được tự tại, giải thoát.",
                    "Giải thoát chúng sinh khỏi lưới bủa của tà kiến, ma vương, đưa về với chánh tri kiến.",
                    "Cứu độ chúng sinh khỏi các tai nạn giam cầm, hình phạt, oan ức tai ương thế gian.",
                    "Ban cho thức ăn, nước uống ngon lành để cứu người đói khát, sau đó ban pháp vị giải thoát.",
                    "Ban cho y phục trang nghiêm, đồ trang sức quý báu cho người nghèo lạnh rách rưới."
                ),
                mantra = "Nam mô bạc già phạt đế, bệ sát xã, lũ lô thích lưu ly, bát lạt bà, hắt ra xà dã. Đát tha yết đa dã, a ra hắt đế, tam miệu tam bột đà dã. Đát điệt tha. Án, bệ sát thệ, bệ sát thệ, bệ sát xã, tam một yết đế sa ha.",
                mantraSanskrit = "Tadyathā: Oṃ bhaiṣajye bhaiṣajye bhaiṣajya-samudgate svāhā",
                imageUrl = "https://images.unsplash.com/photo-1609137144814-7eb3268840eb?w=500&auto=format&fit=crop",
                gradientColors = listOf("#0D47A1", "#1976D2") // Blue tones for Medicine Buddha
            ),
            BuddhaDeity(
                id = 2,
                name = "Đức Phật A Di Đà",
                title = "Tiếp Dẫn Đạo Sư A Di Đà Phật",
                biography = "Đức Phật A Di Đà là giáo chủ của cõi Tây Phương Cực Lạc. Tên của Ngài có nghĩa là Vô Lượng Thọ (thọ mạng vô cương) và Vô Lượng Quang (hào quang vô tận). Ngài tượng trưng cho lòng từ bi dung chứa quảng đại và trí tuệ vô biên soi chiếu mười phương thế giới, tiếp dẫn hương linh vãng sinh.",
                vows = listOf(
                    "Quốc độ không có ba đường ác (địa ngục, ngã quỷ, súc sinh).",
                    "Chúng sinh ở cõi Ngài không còn thối chuyển vào đường ác nữa.",
                    "Thân thể chúng sinh ở cõi Cực Lạc đều có màu vàng ròng trang nghiêm chói lọi.",
                    "Diện mạo chúng sinh đều thanh tịnh bình đẳng, không có phân biệt tốt xấu.",
                    "Mọi chúng sinh đều có thần thông, nhớ được vô số kiếp quá khứ.",
                    "Chúng sinh có thiên nhãn thông soi chiếu mười phương thế giới.",
                    "Chúng sinh có thiên nhĩ thông nghe được pháp âm của chư Phật khắp nơi.",
                    "Chúng sinh có tha tâm thông biết được tâm tư suy nghĩ của người khác.",
                    "Chúng sinh có thần túc thông tự tại du hành khắp mười phương trong nháy mắt.",
                    "Chúng sinh không dính mắc, không tham đắm vào thân thể, thọ dụng.",
                    "Chúng sinh vãng sinh về cõi Cực Lạc đều trụ vào Chánh định tụ cho đến khi thành Phật.",
                    "Hào quang của Ngài vô lượng chiếu sáng không bị ngăn ngại.",
                    "Thọ mạng của Ngài và nhân dân cõi nước Ngài dài lâu vô lượng vô biên vô số kiếp.",
                    "Hàng thanh văn ở cõi nước Ngài nhiều vô số kể không thể tính đếm.",
                    "Chúng sinh niệm danh hiệu Ngài từ một đến mười niệm khi lâm chung đều đắc vãng sinh (Trừ tội phỉ báng Chánh pháp)."
                ),
                mantra = "Nam mô a di đa bà dạ. Đát tha dà đa dạ. Đát địa dạ tha. A di rị đô bà tỳ. A di rị đa tất đam bà tỳ. A di rị đa tỳ ca lan đế. A di rị đa tỳ ca lan đa. Dạ di nị dạ dạ na. Chỉ đa ca lệ sa bà ha.",
                mantraSanskrit = "Oṃ Amṛta Teje Hara Hūṃ",
                imageUrl = "https://images.unsplash.com/photo-1542442828-287217bfb87f?w=500&auto=format&fit=crop",
                gradientColors = listOf("#D84315", "#FF8F00") // Red/Orange tones
            ),
            BuddhaDeity(
                id = 3,
                name = "Quán Thế Âm Nghìn Mắt Nghìn Tay",
                title = "Đại Bi Hội Thượng Phật Bồ Tát Sahasrabhuja",
                biography = "Hóa thân tôn quý nghìn mắt nghìn tay của Bồ Tát Quán Thế Âm tượng trưng cho sự hộ trì rộng khắp. Một nghìn con mắt nằm ở lòng bàn tay để quán sát sâu sắc mọi đau khổ thầm kín của chúng sinh khắp mười phương pháp giới, một nghìn cánh tay hành động tức thì cứu độ che chở không bỏ sót một ai.",
                vows = listOf(
                    "Tầm thanh cứu khổ: Lắng nghe mọi tiếng kêu cứu chánh niệm cứu thoát khổ nạn thế gian.",
                    "Hóa giải ách nạn: Tiêu trừ tai họa lửa, nước, đao binh, quỷ dữ, oán tặc quấy phá.",
                    "Hộ trì bình an: Đem lại sự hanh thông, cát tường, viên mãn cho người thành tâm trì niệm chú Đại Bi.",
                    "Giải trừ phiền não oán thù, chuyển hóa tâm ác, khơi dậy hạt giống từ bi hỷ xả."
                ),
                mantra = "Thiên thủ thiên nhãn vô ngại đại bi tâm đà la ni (Chú Đại Bi): Nam mô hắt ra đát na đa ra dạ da. Nam mô a rị da. Bà lô yết đế thước bát ra da. Bồ đề tát đỏa bà da. Ma ha tát đỏa bà da. Ma ha ca lô ni ca da. Án. Tát bàn ra phạt duệ. Số đát na đát tả...",
                mantraSanskrit = "Oṃ Vajra Dharma Hrīḥ (Tâm chú) / Oṃ Maṇi Padme Hūṃ",
                imageUrl = "https://images.unsplash.com/photo-1590073844006-33379778ae09?w=500&auto=format&fit=crop",
                gradientColors = listOf("#455A64", "#90A4AE") // Mystic slate/white
            ),
            BuddhaDeity(
                id = 4,
                name = "Đức Phật Thích Ca Mâu Ni",
                title = "Bổn Sư Thích Ca Mâu Ni Phật",
                biography = "Đức Phật Thích Ca Mâu Ni (Siddhartha Gautama) là đức Phật lịch sử khai sáng đạo Phật cõi Ta Bà. Xuất thân là Thái tử nước Ca Tỳ La Vệ, Ngài từ bỏ ngai vàng vàng son xuất gia cầu đạo giải thoát. Dưới cội Bồ Đề chánh niệm tĩnh lặng, Ngài chứng đắc Vô Thượng Chính Đẳng Chính Giác, diễn thuyết con đường Trung Đạo cứu khổ.",
                vows = listOf(
                    "Khai thị chúng sinh: Chỉ bày con đường giải thoát khỏi sinh già bệnh chết cứu khổ luân hồi.",
                    "Thiết lập Tăng đoàn: Tạo dựng môi trường tu tập thanh tịnh, chánh niệm hòa hợp.",
                    "Truyền trao giáo lý Bát Chánh Đạo, Tứ Diệu Đế giải thoát khổ đau cho vạn loại chúng sinh."
                ),
                mantra = "Đát điệt tha: Án, mâu ni, mâu ni, ma ha mâu ni, Thích Ca Mâu Ni dã, sa bà ha.",
                mantraSanskrit = "Tadyathā: Oṃ mune mune mahāmune śākyamunaye svāhā",
                imageUrl = "https://images.unsplash.com/photo-1528127269322-539801943592?w=500&auto=format&fit=crop",
                gradientColors = listOf("#EF6C00", "#F9A825") // Golden saffron
            ),
            BuddhaDeity(
                id = 5,
                name = "Phật Di Lặc",
                title = "Đương Lai Hạ Sanh Di Lặc Tôn Phật",
                biography = "Đức Phật Di Lặc là vị Bồ Tát sẽ đắc quả Phật trong tương lai kế thừa đức Thích Ca. Tướng mạo Ngài vô cùng từ ái, chiếc bụng lớn dung chứa mọi chuyện muộn phiền nhân thế, nụ cười hoan hỷ vô biên xua tan mệt mỏi, tượng trưng cho hạnh Từ Bi, Bao Dung, Hỷ Xả và nguồn năng lượng tích cực bình an.",
                vows = listOf(
                    "Mở mang hạnh Từ ái (Từ thị), dùng tình yêu thương thuần khiết hóa giải thù hận, tranh chấp.",
                    "Kiến tạo cõi Ta Bà thanh tịnh thịnh vượng, đưa nhân loại đi vào kỷ nguyên hỷ lạc chánh niệm.",
                    "Độ trì chúng sinh luôn gặp niềm vui, hạnh phúc cát tường, tinh tấn trên con đường giác ngộ."
                ),
                mantra = "Nam mô Di Lặc Tôn Phật / Án di lặc di lặc ma ha di lặc dã sa bà ha.",
                mantraSanskrit = "Oṃ Maitreya Maitreya Mahāmaitriye Svāhā",
                imageUrl = "https://images.unsplash.com/photo-1628155930542-3c7a64e2c833?w=500&auto=format&fit=crop",
                gradientColors = listOf("#F57F17", "#FBC02D") // Amber yellow
            ),
            BuddhaDeity(
                id = 6,
                name = "Quán Thế Âm Bồ Tát",
                title = "Đại Từ Đại Bi Tầm Thanh Cứu Khổ Quán Thế Âm Bồ Tát",
                biography = "Bồ Tát Quán Thế Âm (Avalokiteshvara) hiện thân cho lòng Từ Bi cứu khổ cứu nạn. Ngài thường ngự tại Phổ Đà Sơn, cầm nhành dương liễu và tịnh bình chứa nước cam lộ mát lành rưới tắt ngọn lửa phiền não sân hận trong lòng chúng sinh, đem lại chánh niệm dịu mát.",
                vows = listOf(
                    "Nếu chúng sinh bị lửa dữ thiêu đốt, niệm danh hiệu Ngài lửa liền hóa thành hồ nước mát.",
                    "Nếu bị nước cuốn trôi, niệm danh hiệu Ngài liền gặp chỗ cạn, vớt lên bờ an toàn.",
                    "Nếu bị oán tặc hãm hại, niệm danh hiệu Ngài thì gươm đao oán tặc liền gãy nát.",
                    "Nếu chịu nhiều tham dục, sân hận, si mê, thường niệm và kính lễ Ngài liền đắc giải thoát ly dục."
                ),
                mantra = "Nam mô Đại Từ Đại Bi Cứu Khổ Cứu Nạn Quán Thế Âm Bồ Tát / Án ma ni bát di hồng.",
                mantraSanskrit = "Oṃ Maṇi Padme Hūṃ",
                imageUrl = "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=500&auto=format&fit=crop",
                gradientColors = listOf("#00838F", "#00ACC1") // Turquoise teal
            ),
            BuddhaDeity(
                id = 7,
                name = "Địa Tạng Vương Bồ Tát",
                title = "U Minh Giáo Chủ Bản Tôn Địa Tạng Vương Bồ Tát",
                biography = "Bồ Tát Địa Tạng Vương (Ksitigarbha) nổi tiếng với đại nguyện cứu độ vô tiền khoáng hậu. Ngài ngự nơi cõi u minh tăm tối, tay cầm tích trượng oai linh rung lên mở toang cửa ngục cứu vớt các hương linh, tay nâng ngọc minh châu chiếu sáng phá tan màn đêm tăm tối đau khổ dưới ngục sâu.",
                vows = listOf(
                    "Địa ngục chưa trống rỗng, quyết không chứng quả Phật giải thoát.",
                    "Chúng sinh chịu khổ cực chưa độ tận, quyết chưa chịu nhập Niết Bàn.",
                    "Cứu độ tất cả hương linh vong nhân oán kết nơi cõi âm u được siêu sinh tịnh độ chánh niệm."
                ),
                mantra = "Nam mô Địa Tạng Vương Bồ Tát / Án bát ra mạt lân đà nã sa bà ha.",
                mantraSanskrit = "Oṃ Pramardane Svāhā",
                imageUrl = "https://images.unsplash.com/photo-1518005020951-eccb494ad742?w=500&auto=format&fit=crop",
                gradientColors = listOf("#4E342E", "#8D6E63") // Earth brown/gold
            ),
            BuddhaDeity(
                id = 8,
                name = "Văn Thù Sư Lợi Bồ Tát",
                title = "Đại Trí Văn Thù Sư Lợi Pháp Vương Tử Bồ Tát",
                biography = "Bồ Tát Văn Thù Sư Lợi (Manjushri) là vị thượng thủ tượng trưng cho Trí Tuệ chân thật vô thượng. Ngài ngự trên tòa sen, cưỡi sư tử xanh oai mãnh tượng trưng cho trí lực hàng phục tà ma, tay phải cầm gươm báu trí tuệ chém đứt lưới vô minh phiền não trần thế, tay trái cầm kinh điển Bát Nhã.",
                vows = listOf(
                    "Dùng ánh sáng vô cấu tiêu trừ màng tối si mê vô minh cho toàn thể chúng sinh.",
                    "Ban cho trí tuệ minh mẫn học rộng nghe nhiều, thấu đạt sâu sắc giáo pháp giải thoát.",
                    "Giúp hành giả vượt qua mê lầm oán kết để nhận chân tự tính thanh tịnh chánh niệm."
                ),
                mantra = "Án a ra ba dạ na đế / Oṃ A Ra Pa Ca Na Dhīḥ.",
                mantraSanskrit = "Oṃ A Ra Pa Ca Na Dhīḥ",
                imageUrl = "https://images.unsplash.com/photo-1578496479914-7235024ac77c?w=500&auto=format&fit=crop",
                gradientColors = listOf("#2E7D32", "#4CAF50") // Green/emerald forest
            ),
            BuddhaDeity(
                id = 9,
                name = "Phổ Hiền Bồ Tát",
                title = "Đại Hạnh Phổ Hiền Vương Bồ Tát",
                biography = "Bồ Tát Phổ Hiền (Samantabhadra) đại diện cho Đại Hạnh, năng lực hành động và thực chứng vĩ đại. Ngài cưỡi voi trắng sáu ngà hiền hòa oai nghiêm biểu thị cho Lục độ vạn hạnh kiên trì vượt gian khó, tay cầm đóa hoa sen biểu thị cho tự tính thanh khiết trong hành động vị tha.",
                vows = listOf(
                    "Kính lễ mười phương chư Phật đồng hành tu học.",
                    "Xưng tán vinh danh công đức vô lượng của đức Như Lai.",
                    "Quảng tu rộng lớn cúng dường chánh niệm tịnh tài tịnh vật cho tăng chúng.",
                    "Sám hối tiêu trừ mọi nghiệp chướng si mê từ quá khứ.",
                    "Tùy hỷ vui vẻ với công đức lành của tất cả chúng sinh gieo mầm.",
                    "Thỉnh Phật chuyển bánh xe Chánh Pháp giảng dạy độ đời.",
                    "Thỉnh Phật trụ thế gian dài lâu cứu giúp muôn loài.",
                    "Thường tùy học theo gương sáng thanh tịnh của chư Phật.",
                    "Hằng thuận lợi ích, tôn trọng chúng sinh như cha mẹ tôn kính.",
                    "Phổ giai hồi hướng toàn bộ công đức lành về quả vị Vô Thượng Bồ Đề."
                ),
                mantra = "Oṃ Samantabhadra Bodhisattva Svāhā / Án Tam muội da tát đỏa phạm.",
                mantraSanskrit = "Oṃ Samaya Stvaṃ",
                imageUrl = "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=500&auto=format&fit=crop",
                gradientColors = listOf("#37474F", "#546E7A") // Mountain grey
            ),
            BuddhaDeity(
                id = 10,
                name = "Đại Thế Chí Bồ Tát",
                title = "Đại Thế Chí Pháp Vương Tử Bồ Tát Mahasthamaprapta",
                biography = "Bồ Tát Đại Thế Chí đứng bên hữu đức Phật A Di Đà trong Tây Phương Tam Thánh. Ngài dùng ánh sáng trí tuệ rực rỡ (Đại Lực) chiếu soi muôn nơi giúp chúng sinh thoát khỏi ba đường ác (địa ngục, ngã quỷ, súc sinh) dũng mãnh tu tập thoát ly sinh tử phiền não.",
                vows = listOf(
                    "Phóng ánh sáng trí tuệ soi đường dẹp tà kiến u tối cho người tu hành.",
                    "Hộ trì hành giả dũng mãnh tinh tấn chánh niệm niệm Phật tự quy y.",
                    "Dẫn dắt vong nhân nương tựa nguyện lực Phật vãng sinh Tây Phương Cực Lạc."
                ),
                mantra = "Nam mô Đại Thế Chí Bồ Tát / Oṃ Śāntiḥ Śāntiḥ Śāntiḥ.",
                mantraSanskrit = "Oṃ Vajra Chanda Mahāroṣaṇa Hūṃ",
                imageUrl = "https://images.unsplash.com/photo-1501854140801-50d01698950b?w=500&auto=format&fit=crop",
                gradientColors = listOf("#AD1457", "#D81B60") // Purple/pink ruby
            ),
            BuddhaDeity(
                id = 11,
                name = "Chuẩn Đề Bồ Tát",
                title = "Thất Câu Chi Phật Mẫu Chuẩn Đề Bồ Tát",
                biography = "Bồ Tát Chuẩn Đề là vị hộ trì Phật pháp vĩ đại tôn xưng là Mẹ của mười phương bảy mươi ức chư Phật. Ngài có mười tám cánh tay cầm vô số pháp khí thần thông biểu thị cho các phương tiện thiện xảo điều phục tâm ma quấy phá, hộ trì bình an hỷ lạc.",
                vows = listOf(
                    "Tiêu diệt oán kết tai ách, cứu người trì niệm khỏi hiểm họa ma quỷ ngoại đạo.",
                    "Độ cho người tu hành gia đạo hanh thông, công việc viên mãn, trí tuệ hanh thông.",
                    "Hàng phục nội ma (tham sân si) và ngoại ma giúp hành giả thăng tiến quả vị bồ-đề."
                ),
                mantra = "Khư rị chủ rị chuẩn đề sa bà ha (Chuẩn Đề Thần Chú): Namaḥ saptānāṃ samyaksambuddha koṭīnāṃ. Tadyathā: Oṃ cale cule cunde svāhā.",
                mantraSanskrit = "Oṃ cale cule cunde svāhā",
                imageUrl = "https://images.unsplash.com/photo-1495107334309-fcf20504a5ab?w=500&auto=format&fit=crop",
                gradientColors = listOf("#5E35B1", "#7E57C2") // Purple amethyst
            ),
            BuddhaDeity(
                id = 12,
                name = "Đại Nhật Như Lai",
                title = "Tỳ Lô Giá Na Phật Vairocana Như Lai",
                biography = "Đức Phật Đại Nhật (Vairocana) biểu thị cho Pháp Thân thanh tịnh thường trụ của vũ trụ pháp giới chư Phật. Ánh sáng trí tuệ chói lọi vô ngại của Ngài chiếu soi khắp pháp giới bình đẳng, tịnh hóa tất cả cõi nước mê lầm vô minh, khơi dậy chánh niệm Phật tính trong tim chúng sinh.",
                vows = listOf(
                    "Tịnh hóa cõi nước hư hoại si mê thành bảo điện pháp giới sáng sạch.",
                    "Truyền thọ chân ngôn mật pháp dẫn dắt chúng sinh thực hành chánh định tức thân thành Phật.",
                    "Soi sáng dẹp sạch bóng tối mê lầm ngã chấp ngàn đời trong tâm ý hành giả."
                ),
                mantra = "Án a vĩ la hồng khiếm / Oṃ Vairocana Hūṃ.",
                mantraSanskrit = "Oṃ Vairocana Hūṃ",
                imageUrl = "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=500&auto=format&fit=crop",
                gradientColors = listOf("#00695C", "#00897B") // Emerald green/teal
            ),
            BuddhaDeity(
                id = 13,
                name = "Tôn giả Ma Ha Ca Diếp",
                title = "Maha Kassapa Đầu Đà Đệ Nhất Tổ Sư",
                biography = "Tôn giả Ma Ha Ca Diếp là đại đệ tử đệ nhất tu hành Đầu Đà khổ hạnh thanh bần của Đức Thích Ca. Ngài là người duy nhất mỉm cười đón nhận mật pháp truyền thừa khi đức Phật giơ đóa sen lên núi Linh Thứu (Niêm hoa vi tiếu), khai sinh dòng thiền chánh niệm truyền thế.",
                vows = listOf(
                    "Xả ly hoàn toàn danh lợi vật chất thế gian, bảo lưu nếp sống phạm hạnh chân thật tột bực.",
                    "Bảo vệ gìn giữ Chánh Pháp không bị lai tạp mờ mờ sau khi đức Thế Tôn nhập Niết Bàn.",
                    "Làm tấm gương kiên định tột bực cho hành giả phát tâm dấn thân tu thiền định."
                ),
                mantra = "Nam mô Đầu đà đệ nhất Ma Ha Ca Diếp tôn giả / Oṃ Kassapaye Svāhā.",
                mantraSanskrit = "Oṃ Kassapaye Svāhā",
                imageUrl = "https://images.unsplash.com/photo-1475113548554-5a36f1f523d6?w=500&auto=format&fit=crop",
                gradientColors = listOf("#3E2723", "#5D4037") // Deep wood brown
            ),
            BuddhaDeity(
                id = 14,
                name = "Tôn giả A Nan Đà",
                title = "Ananda Đa Văn Đệ Nhất Thị Giả Tôn Giả",
                biography = "Tôn giả A Nan Đà là em họ đồng thời là thị giả tận tụy kề cận chăm sóc Đức Phật suốt đời. Ngài có trí nhớ siêu phàm vô song nghe một lần ghi nhớ trọn đời, là người trùng tuyên lại toàn bộ Kinh Điển chánh niệm trong đại hội kiết tập lần thứ nhất cứu giúp hậu thế học pháp.",
                vows = listOf(
                    "Tận tụy quên mình phụng sự Phật tổ, chăm lo chu đáo cho tăng chúng hòa hợp.",
                    "Bảo lưu nguyên vẹn từng lời dạy vàng ngọc của đức Thế Tôn truyền bá muôn thuở.",
                    "Hộ trì cho hàng ni giới đắc quyền xuất gia tu học thoát khổ phiền não tự tại."
                ),
                mantra = "Oṃ Śruti Smṛti Vijayata Svāhā (Chú tăng trưởng trí nhớ, ghi tạc giáo pháp).",
                mantraSanskrit = "Oṃ Ānandaye Svāhā",
                imageUrl = "https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?w=500&auto=format&fit=crop",
                gradientColors = listOf("#0D47A1", "#1565C0") // Ocean blue
            ),
            BuddhaDeity(
                id = 15,
                name = "Tổ sư Bồ Đề Đạt Ma",
                title = "Bodhidharma Sơ Tổ Thiền Tông Trung Hoa",
                biography = "Tổ sư Bồ Đề Đạt Ma xuất thân là thái tử Nam Ấn Độ, vâng lệnh thầy sang Đông Độ truyền pháp. Ngài nổi tiếng với điển tích '9 năm quay mặt vào vách thiền định' tại chùa Thiếu Lâm và triết lý 'Bất lập văn tự, giáo ngoại biệt truyền, trực chỉ nhân tâm, kiến tính thành Phật' đưa hành giả thẳng về Phật tính.",
                vows = listOf(
                    "Phá bỏ sự bám chấp khô cứng vào giáo điều câu chữ vô hồn để tìm lại tâm Phật chân thật.",
                    "Khơi mở dòng thiền chánh niệm tự chứng vô song tự lực giải thoát phiền não trần thế.",
                    "Truyền trao y bát chánh pháp chính thống hóa độ nhân loại chánh niệm thực tiễn."
                ),
                mantra = "Oṃ Bodhidharmaye Hūṃ Phaṭ (Tâm chú dũng mãnh dập tắt vọng tưởng thiền định).",
                mantraSanskrit = "Oṃ Bodhidharmaye Svāhā",
                imageUrl = "https://images.unsplash.com/photo-1500627869374-13cd993b1115?w=500&auto=format&fit=crop",
                gradientColors = listOf("#212121", "#424242") // Iron grey/dark Zen
            ),
            BuddhaDeity(
                id = 16,
                name = "Vi Đà Tôn Thiên Bồ Tát",
                title = "Vi Đà Hộ Pháp Tôn Thiên Bồ Tát",
                biography = "Bồ Tát Vi Đà là vị hộ pháp dũng mãnh hàng đầu của Phật giáo. Thân mặc giáp sắt kiên cố, tay chống bảo kiếm hàng ma hoặc nâng chày Giáng Ma dũng lực bảo vệ già lam, gìn giữ kinh sách và hộ trì cho tăng ni, Phật tử yên tâm chánh niệm tu tập không bị nhiễu loạn.",
                vows = listOf(
                    "Nguyện tuần tra pháp giới, dẹp sạch tà ma, bảo vệ sự tôn nghiêm của chùa chiền Tăng bảo.",
                    "Hộ trì che chở người tu hành vượt qua chướng duyên khó khăn quấy nhiễu.",
                    "Gìn giữ Kinh điển chánh pháp trường tồn lâu dài không bị tàn phá bóp méo."
                ),
                mantra = "Oṃ Veda Senādhipatiye Svāhā / Nam mô Vi Đà Tôn Thiên Bồ Tát oai thần.",
                mantraSanskrit = "Oṃ Veda Senādhipatiye Svāhā",
                imageUrl = "https://images.unsplash.com/photo-1513836279014-a89f7a76ae86?w=500&auto=format&fit=crop",
                gradientColors = listOf("#3F51B5", "#5C6BC0") // Royal indigo blue
            ),
            BuddhaDeity(
                id = 17,
                name = "Kim Cang Thủ Bồ Tát",
                title = "Vajrapani Bí Mật Chủ Bồ Tát Đại Thế Lực",
                biography = "Bồ Tát Kim Cang Thủ (Vajrapani) đại diện cho sức mạnh oai dũng kiên cố đệ nhất của chư Phật pháp giới. Tay cầm bảo chày Kim Cang sấm sét sắc bén, Ngài diệt trừ tà kiến ác bá, đập tan mọi chướng ngại rào cản nội tâm dũng mãnh chánh niệm xông pha cứu độ sinh linh.",
                vows = listOf(
                    "Hàng phục oai mãnh mọi ác nhân ma quỷ làm hại đạo pháp chúng sinh.",
                    "Ban cho người tu tập nghị lực dũng mãnh kiên định như kim cương vượt qua nghịch cảnh nghịch duyên.",
                    "Bảo vệ hộ trì mật tông pháp môn bí mật gìn giữ hạt giống chánh niệm tịnh tịnh."
                ),
                mantra = "Oṃ Vajrapāṇi Hūṃ Phaṭ (Chú Kim Cang dẹp tan bóng tối ma đạo oai linh).",
                mantraSanskrit = "Oṃ Vajrapāṇi Hūṃ Phaṭ",
                imageUrl = "https://images.unsplash.com/photo-1418065460487-3e41a6c84dc5?w=500&auto=format&fit=crop",
                gradientColors = listOf("#01579B", "#0288D1") // Sky/thunder blue
            ),
            BuddhaDeity(
                id = 18,
                name = "Đức Tara",
                title = "Đa La Bồ Tát Lục Độ Tara Mẫu Tôn",
                biography = "Đức Tara (Đa La Bồ Tát - Green Tara) sinh ra từ nước mắt đại từ đại bi của Quán Thế Âm Bồ Tát khi quán thấy chúng sinh đau khổ vô tận. Ngài đại diện cho hành động cứu độ siêu tốc vô biên che chở che tai cứu ách ban phát an lành hạnh thông tức thì cho ai thành kính kêu gọi niệm trì.",
                vows = listOf(
                    "Luôn mang thân nữ tướng độ sinh cứu khổ bộc lộ tình mẫu tử từ ái bao dung vô tận.",
                    "Giải thoát hành giả tức khắc khỏi 8 đại nạn nguy hiểm (Sư tử, voi điên, lửa dữ, rắn độc, cướp đoat, ngục tù, sóng thần, quỷ ăn thịt).",
                    "Thực thi nhanh như chớp mọi ước nguyện lành lương thiện của chúng sinh phát nguyện tinh tấn."
                ),
                mantra = "Án ta rê tu ta rê tu rê sa bà ha / Oṃ Tāre Tuttāre Ture Svāhā.",
                mantraSanskrit = "Oṃ Tāre Tuttāre Ture Svāhā",
                imageUrl = "https://images.unsplash.com/photo-1502082553048-f009c37129b9?w=500&auto=format&fit=crop",
                gradientColors = listOf("#1B5E20", "#2E7D32") // Emerald green for Green Tara
            )
        )
    }
}
